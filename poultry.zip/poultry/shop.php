<?php
/**
 * Shop / Buy Poultry & Poultry Products Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'Buy Poultry & Products';
require_once __DIR__ . '/includes/header.php';

$pdo = get_db();

// 1. Fetch all categories
$categories = [];
try {
    $stmt = $pdo->query("SELECT * FROM `categories` ORDER BY `id` ASC");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {}

// 2. Filter & Search Parameters
$selected_category = clean_input($_GET['category'] ?? '');
$search_query = clean_input($_GET['q'] ?? '');
$sort = clean_input($_GET['sort'] ?? 'default');

// 3. Build SQL query for products
$sql = "SELECT p.*, c.name AS category_name, c.slug AS category_slug 
        FROM `products` p 
        LEFT JOIN `categories` c ON p.category_id = c.id 
        WHERE p.status = 'active'";
$params = [];

if (!empty($selected_category)) {
    $sql .= " AND c.slug = ?";
    $params[] = $selected_category;
}

if (!empty($search_query)) {
    $sql .= " AND (p.name LIKE ? OR p.description LIKE ?)";
    $params[] = '%' . $search_query . '%';
    $params[] = '%' . $search_query . '%';
}

switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY p.price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY p.price DESC";
        break;
    case 'name_asc':
        $sql .= " ORDER BY p.name ASC";
        break;
    default:
        $sql .= " ORDER BY p.featured DESC, p.id ASC";
        break;
}

$products = [];
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
} catch (Exception $e) {}
?>

<!-- SHOP HERO -->
<section class="bg-success text-white py-4 mb-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h1 class="h2 fw-bold mb-1">Buy Poultry & Farm Products</h1>
                <p class="text-white-50 mb-0 small">Direct from hatchery and coop to your doorstep. Guaranteed healthy & organic.</p>
            </div>
            <div class="col-md-5 text-md-end mt-3 mt-md-0">
                <a href="/poultry/cart.php" class="btn btn-warning text-dark fw-bold px-3 py-2 rounded-pill">
                    <i class="bi bi-cart3 me-1"></i> View Cart & Checkout (<?= get_cart_count() ?> items)
                </a>
            </div>
        </div>
    </div>
</section>

<div class="container pb-5">
    <!-- SEARCH & FILTER BAR -->
    <div class="card border-0 shadow-sm rounded-4 p-3 mb-4">
        <form method="GET" action="shop.php" class="row g-3 align-items-center">
            <!-- Search Input -->
            <div class="col-lg-5 col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" name="q" class="form-control border-start-0 bg-light" placeholder="Search broilers, chicks, eggs, feeds..." value="<?= htmlspecialchars($search_query) ?>">
                    <?php if (!empty($selected_category)): ?>
                        <input type="hidden" name="category" value="<?= htmlspecialchars($selected_category) ?>">
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sort By -->
            <div class="col-lg-4 col-md-3">
                <div class="input-group">
                    <label class="input-group-text bg-light"><i class="bi bi-sort-down text-muted"></i></label>
                    <select name="sort" class="form-select bg-light" onchange="this.form.submit()">
                        <option value="default" <?= $sort === 'default' ? 'selected' : '' ?>>Sort: Featured First</option>
                        <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price: Low to High</option>
                        <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
                        <option value="name_asc" <?= $sort === 'name_asc' ? 'selected' : '' ?>>Name: A to Z</option>
                    </select>
                </div>
            </div>

            <!-- Submit / Reset Buttons -->
            <div class="col-lg-3 col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-farm-primary w-100 fw-semibold">
                    <i class="bi bi-funnel me-1"></i> Filter
                </button>
                <?php if (!empty($selected_category) || !empty($search_query) || $sort !== 'default'): ?>
                    <a href="shop.php" class="btn btn-outline-secondary" title="Reset Filters">
                        <i class="bi bi-x-circle"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- CATEGORY PILLS FILTER -->
    <div class="d-flex flex-wrap gap-2 mb-4 pb-2">
        <a href="shop.php<?= !empty($search_query) ? '?q=' . urlencode($search_query) : '' ?>" class="btn btn-sm rounded-pill px-3 fw-bold <?= empty($selected_category) ? 'btn-success text-white' : 'btn-outline-secondary' ?>">
            <i class="bi bi-grid me-1"></i> All Products
        </a>
        <?php foreach ($categories as $cat): ?>
            <a href="shop.php?category=<?= urlencode($cat['slug']) ?><?= !empty($search_query) ? '&q=' . urlencode($search_query) : '' ?>" 
               class="btn btn-sm rounded-pill px-3 fw-bold <?= $selected_category === $cat['slug'] ? 'btn-success text-white' : 'btn-outline-secondary' ?>">
                <i class="bi <?= htmlspecialchars($cat['icon'] ?? 'bi-tag') ?> me-1"></i> <?= htmlspecialchars($cat['name']) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- PRODUCTS GRID -->
    <?php if (!empty($products)): ?>
        <div class="row g-4">
            <?php foreach ($products as $p): ?>
                <div class="col-sm-6 col-md-4 col-lg-3">
                    <div class="product-card">
                        <div class="product-image-container">
                            <img src="<?= htmlspecialchars($p['image_url'] ?? 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=600&q=80') ?>" alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
                            
                            <span class="product-badge-category">
                                <?= htmlspecialchars($p['category_name'] ?? 'Poultry') ?>
                            </span>

                            <?php if ($p['stock_quantity'] > 10): ?>
                                <span class="badge bg-success product-badge-stock">In Stock (<?= $p['stock_quantity'] ?>)</span>
                            <?php elseif ($p['stock_quantity'] > 0): ?>
                                <span class="badge bg-warning text-dark product-badge-stock">Low Stock (<?= $p['stock_quantity'] ?>)</span>
                            <?php else: ?>
                                <span class="badge bg-danger product-badge-stock">Out of Stock</span>
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <h5 class="card-title fw-bold mb-1 text-truncate" title="<?= htmlspecialchars($p['name']) ?>">
                                <?= htmlspecialchars($p['name']) ?>
                            </h5>
                            
                            <p class="text-muted small mb-3 flex-grow-1" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" title="<?= htmlspecialchars($p['description'] ?? '') ?>">
                                <?= htmlspecialchars($p['description'] ?? 'Quality farm fresh product.') ?>
                            </p>

                            <div class="d-flex justify-content-between align-items-baseline mb-3">
                                <div>
                                    <span class="product-price-tag"><?= format_currency($p['price']) ?></span>
                                </div>
                                <span class="product-unit-tag"><?= htmlspecialchars($p['unit']) ?></span>
                            </div>

                            <div class="d-flex gap-2">
                                <input type="number" class="form-control form-control-sm text-center qty-input" data-product-id="<?= $p['id'] ?>" value="1" min="1" max="<?= $p['stock_quantity'] ?>" style="width: 60px;" <?= $p['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                <button class="btn btn-farm-primary btn-sm flex-grow-1 btn-add-to-cart" data-product-id="<?= $p['id'] ?>" <?= $p['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                    <i class="bi bi-cart-plus me-1"></i> Add to Cart
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="card border-0 shadow-sm rounded-4 text-center py-5">
            <div class="card-body">
                <i class="bi bi-search fs-1 text-muted d-block mb-3"></i>
                <h4 class="fw-bold mb-2">No Poultry Products Found</h4>
                <p class="text-muted mb-4">We couldn't find any items matching your active category or search query.</p>
                <a href="shop.php" class="btn btn-farm-primary px-4 py-2 rounded-pill">
                    <i class="bi bi-arrow-clockwise me-1"></i> View All Products
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
