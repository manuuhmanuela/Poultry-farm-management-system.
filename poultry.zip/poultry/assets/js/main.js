/**
 * FeatherFarm - Main JavaScript Controller
 * Handles shopping cart, AJAX requests, toast notifications & interactive UI
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Toast Notification Container Setup
    createToastContainer();

    // 2. Add to Cart buttons
    document.querySelectorAll('.btn-add-to-cart').forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            const productId = this.getAttribute('data-product-id');
            const qtyInput = document.querySelector(`.qty-input[data-product-id="${productId}"]`);
            const quantity = qtyInput ? parseInt(qtyInput.value) || 1 : 1;

            addToCart(productId, quantity, this);
        });
    });

    // 3. Cart Page Quantity Increment/Decrement
    document.querySelectorAll('.btn-cart-qty-plus').forEach(button => {
        button.addEventListener('click', function () {
            const productId = this.getAttribute('data-product-id');
            const input = document.querySelector(`.cart-qty-input[data-product-id="${productId}"]`);
            if (input) {
                const max = parseInt(input.getAttribute('max')) || 9999;
                let currentVal = parseInt(input.value) || 1;
                if (currentVal < max) {
                    input.value = currentVal + 1;
                    updateCartItem(productId, input.value);
                } else {
                    showToast(`Maximum available stock reached (${max})`, 'warning');
                }
            }
        });
    });

    document.querySelectorAll('.btn-cart-qty-minus').forEach(button => {
        button.addEventListener('click', function () {
            const productId = this.getAttribute('data-product-id');
            const input = document.querySelector(`.cart-qty-input[data-product-id="${productId}"]`);
            if (input) {
                let currentVal = parseInt(input.value) || 1;
                if (currentVal > 1) {
                    input.value = currentVal - 1;
                    updateCartItem(productId, input.value);
                }
            }
        });
    });

    // 4. Cart Page Direct Input Change
    document.querySelectorAll('.cart-qty-input').forEach(input => {
        input.addEventListener('change', function () {
            const productId = this.getAttribute('data-product-id');
            const max = parseInt(this.getAttribute('max')) || 9999;
            let val = parseInt(this.value) || 1;
            if (val < 1) val = 1;
            if (val > max) {
                val = max;
                showToast(`Adjusted to maximum available stock (${max})`, 'warning');
            }
            this.value = val;
            updateCartItem(productId, val);
        });
    });

    // 5. Remove Item from Cart
    document.querySelectorAll('.btn-cart-remove').forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            const productId = this.getAttribute('data-product-id');
            removeCartItem(productId);
        });
    });

    // 6. Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});

/**
 * Create Toast container if not present
 */
function createToastContainer() {
    if (!document.getElementById('toast-container')) {
        const container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(container);
    }
}

/**
 * Display a modern Bootstrap 5 toast notification
 */
function showToast(message, type = 'success') {
    createToastContainer();
    const container = document.getElementById('toast-container');

    const toastId = 'toast-' + Date.now();
    const bgClass = type === 'success' ? 'bg-success text-white' : 
                    type === 'danger' ? 'bg-danger text-white' : 
                    type === 'warning' ? 'bg-warning text-dark' : 'bg-primary text-white';

    const icon = type === 'success' ? 'bi-check-circle-fill' :
                 type === 'danger' ? 'bi-exclamation-octagon-fill' :
                 type === 'warning' ? 'bi-exclamation-triangle-fill' : 'bi-info-circle-fill';

    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center ${bgClass} border-0 shadow-lg mb-2" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body d-flex align-items-center">
                    <i class="bi ${icon} fs-5 me-2"></i>
                    <div>${message}</div>
                </div>
                <button type="button" class="btn-close ${type !== 'warning' ? 'btn-close-white' : ''} me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    container.insertAdjacentHTML('beforeend', toastHtml);
    const toastElement = document.getElementById(toastId);
    const bsToast = new bootstrap.Toast(toastElement, { delay: 4000 });
    bsToast.show();

    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });
}

/**
 * Update the navbar cart count badge
 */
function updateCartBadge(count) {
    const badges = document.querySelectorAll('.cart-count-badge');
    badges.forEach(badge => {
        badge.textContent = count;
        if (count > 0) {
            badge.classList.remove('d-none');
        } else {
            badge.classList.add('d-none');
        }
    });
}

/**
 * Add a product to cart via AJAX
 */
function addToCart(productId, quantity, triggerButton = null) {
    let originalHtml = '';
    if (triggerButton) {
        originalHtml = triggerButton.innerHTML;
        triggerButton.disabled = true;
        triggerButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Adding...';
    }

    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('product_id', productId);
    formData.append('quantity', quantity);

    fetch('/poultry/api/cart-actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartBadge(data.cart_count);
            showToast(data.message, 'success');
            if (data.warning) {
                showToast(data.warning, 'warning');
            }
        } else {
            showToast(data.message || 'Could not add item to cart', 'danger');
        }
    })
    .catch(err => {
        showToast('Network error while updating cart.', 'danger');
        console.error(err);
    })
    .finally(() => {
        if (triggerButton) {
            triggerButton.disabled = false;
            triggerButton.innerHTML = originalHtml;
        }
    });
}

/**
 * Update cart item quantity on cart page
 */
function updateCartItem(productId, quantity) {
    const formData = new FormData();
    formData.append('action', 'update');
    formData.append('product_id', productId);
    formData.append('quantity', quantity);

    fetch('/poultry/api/cart-actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartBadge(data.cart_count);
            // Refresh totals on the page
            updateCartTotalsDOM(data, productId);
        } else {
            showToast(data.message, 'danger');
        }
    })
    .catch(err => console.error(err));
}

/**
 * Remove an item from the cart
 */
function removeCartItem(productId) {
    const formData = new FormData();
    formData.append('action', 'remove');
    formData.append('product_id', productId);

    fetch('/poultry/api/cart-actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartBadge(data.cart_count);
            showToast(data.message, 'info');

            const itemRow = document.getElementById(`cart-row-${productId}`);
            if (itemRow) {
                itemRow.remove();
            }

            if (data.cart_count === 0) {
                // If cart is empty, reload page to show empty cart banner
                window.location.reload();
            } else {
                updateCartTotalsDOM(data);
            }
        } else {
            showToast(data.message, 'danger');
        }
    })
    .catch(err => console.error(err));
}

/**
 * Update cart totals and line subtotals in the DOM
 */
function updateCartTotalsDOM(data, activeProductId = null) {
    // Update subtotal
    const subtotalEl = document.getElementById('cart-subtotal');
    if (subtotalEl) subtotalEl.textContent = data.formatted_subtotal;

    // Update delivery fee
    const deliveryEl = document.getElementById('cart-delivery-fee');
    if (deliveryEl) deliveryEl.textContent = data.formatted_delivery_fee;

    // Update grand total
    const grandTotalEl = document.getElementById('cart-grand-total');
    if (grandTotalEl) grandTotalEl.textContent = data.formatted_grand_total;

    // Update individual product line subtotal if item details returned
    if (data.items && activeProductId) {
        const item = data.items.find(i => parseInt(i.product_id) === parseInt(activeProductId));
        if (item) {
            const lineSubtotalEl = document.getElementById(`line-subtotal-${activeProductId}`);
            if (lineSubtotalEl) {
                const currency = document.body.getAttribute('data-currency') || '$';
                lineSubtotalEl.textContent = currency + parseFloat(item.subtotal).toFixed(2);
            }
        }
    }
}
