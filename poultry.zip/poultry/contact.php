<?php
/**
 * Contact Us & Farm Inquiries Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'Contact Us';
require_once __DIR__ . '/includes/header.php';

$success = false;
$error = '';
$name = '';
$email = '';
$phone = '';
$subject = clean_input($_GET['subject'] ?? '');
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean_input($_POST['name'] ?? '');
    $email = clean_input($_POST['email'] ?? '');
    $phone = clean_input($_POST['phone'] ?? '');
    $subject = clean_input($_POST['subject'] ?? '');
    $message = clean_input($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = 'Please fill out all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            $pdo = get_db();
            $stmt = $pdo->prepare("INSERT INTO `contact_messages` (`name`, `email`, `phone`, `subject`, `message`) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $phone, $subject, $message]);

            $success = true;
            $name = '';
            $email = '';
            $phone = '';
            $subject = '';
            $message = '';
        } catch (Exception $e) {
            $error = 'Failed to submit message: ' . $e->getMessage();
        }
    }
}
?>

<!-- CONTACT HERO -->
<section class="bg-success text-white py-5">
    <div class="container text-center py-3">
        <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-bold text-uppercase mb-3">
            Get in Touch
        </span>
        <h1 class="display-5 fw-bold mb-2">Contact Our Poultry Farm</h1>
        <p class="lead text-white-50 max-w-700 mx-auto">
            Have questions about chick booking, wholesale egg contracts, or veterinary consultancy? We are here to help.
        </p>
    </div>
</section>

<div class="container py-5">
    <div class="row g-5">
        <!-- CONTACT INFO CARDS -->
        <div class="col-lg-5">
            <h3 class="fw-bold mb-4">Farm Headquarters & Inquiries</h3>

            <div class="d-flex flex-column gap-4">
                <div class="d-flex align-items-start gap-3">
                    <div class="service-icon-box m-0" style="width: 50px; height: 50px; font-size: 1.4rem;">
                        <i class="bi bi-geo-alt-fill"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-1">Farm Location</h6>
                        <p class="text-muted small mb-0"><?= htmlspecialchars(get_setting('address', 'Plot 42 Green Valley Rd, Sunrise Agricultural Hub, CA 90210')) ?></p>
                    </div>
                </div>

                <div class="d-flex align-items-start gap-3">
                    <div class="service-icon-box m-0" style="width: 50px; height: 50px; font-size: 1.4rem;">
                        <i class="bi bi-telephone-fill"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-1">Phone & WhatsApp</h6>
                        <p class="text-muted small mb-1">Support: <a href="tel:<?= htmlspecialchars(get_setting('phone')) ?>" class="text-dark fw-bold text-decoration-none"><?= htmlspecialchars(get_setting('phone', '+1 (555) 789-2345')) ?></a></p>
                        <p class="text-muted small mb-0">Hatchery Hotline: <strong>+1 (555) 019-3388</strong></p>
                    </div>
                </div>

                <div class="d-flex align-items-start gap-3">
                    <div class="service-icon-box m-0" style="width: 50px; height: 50px; font-size: 1.4rem;">
                        <i class="bi bi-envelope-fill"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-1">Email Addresses</h6>
                        <p class="text-muted small mb-0"><a href="mailto:<?= htmlspecialchars(get_setting('email', 'info@poultryfarm.com')) ?>" class="text-decoration-none text-success"><?= htmlspecialchars(get_setting('email', 'info@poultryfarm.com')) ?></a></p>
                        <p class="text-muted small mb-0">wholesale@poultryfarm.com</p>
                    </div>
                </div>

                <div class="d-flex align-items-start gap-3">
                    <div class="service-icon-box m-0" style="width: 50px; height: 50px; font-size: 1.4rem;">
                        <i class="bi bi-clock-fill"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-1">Working & Dispatch Hours</h6>
                        <p class="text-muted small mb-0"><?= htmlspecialchars(get_setting('working_hours', 'Monday - Saturday: 7:00 AM - 6:00 PM')) ?></p>
                        <p class="text-muted small mb-0">Sunday: 8:00 AM - 2:00 PM (Emergency Chick Pickup Only)</p>
                    </div>
                </div>
            </div>

            <!-- Map Mockup -->
            <div class="card border-0 rounded-4 shadow-sm overflow-hidden mt-4">
                <div class="bg-light p-4 text-center">
                    <i class="bi bi-map fs-1 text-success d-block mb-2"></i>
                    <h6 class="fw-bold mb-1">Farm Gate Visits & Inspections</h6>
                    <p class="small text-muted mb-0">Due to strict biosecurity protocols, prior booking is required for physical hatchery visits.</p>
                </div>
            </div>
        </div>

        <!-- CONTACT FORM -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-lg rounded-4 p-4 p-md-5">
                <h3 class="fw-bold mb-1">Send Us a Message</h3>
                <p class="text-muted small mb-4">Fill out the inquiry form below and our farm representative will respond within 24 hours.</p>

                <?php if ($success): ?>
                    <div class="alert alert-success d-flex align-items-center mb-4" role="alert">
                        <i class="bi bi-check-circle-fill fs-4 me-3"></i>
                        <div>
                            <h6 class="alert-heading mb-1 fw-bold">Message Sent Successfully!</h6>
                            <p class="mb-0 small">Thank you for reaching out. We have logged your request and will contact you shortly.</p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                        <i class="bi bi-exclamation-triangle-fill fs-5 me-2"></i>
                        <div><?= $error ?></div>
                    </div>
                <?php endif; ?>

                <form method="POST" action="contact.php">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label for="name" class="form-label fw-semibold small">Your Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($name) ?>" placeholder="e.g. Michael Smith" required>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label fw-semibold small">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email) ?>" placeholder="name@example.com" required>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label for="phone" class="form-label fw-semibold small">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($phone) ?>" placeholder="+1 (555) 000-0000">
                        </div>
                        <div class="col-md-6">
                            <label for="subject" class="form-label fw-semibold small">Subject <span class="text-danger">*</span></label>
                            <select class="form-select" id="subject" name="subject" required>
                                <option value="">Select Topic...</option>
                                <option value="Day-Old Chicks Booking" <?= $subject === 'Day-Old Chicks Booking' ? 'selected' : '' ?>>Day-Old Chicks Booking</option>
                                <option value="Wholesale Eggs Supply" <?= $subject === 'Wholesale Eggs Supply' ? 'selected' : '' ?>>Wholesale Eggs Supply</option>
                                <option value="Veterinary Consultancy" <?= $subject === 'Veterinary Consultancy' ? 'selected' : '' ?>>Veterinary Consultancy</option>
                                <option value="Feed Orders & Quotes" <?= $subject === 'Feed Orders & Quotes' ? 'selected' : '' ?>>Feed Orders & Quotes</option>
                                <option value="Order Tracking Inquiry" <?= $subject === 'Order Tracking Inquiry' ? 'selected' : '' ?>>Order Tracking Inquiry</option>
                                <option value="Other Inquiries" <?= $subject === 'Other Inquiries' ? 'selected' : '' ?>>Other Inquiries</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="message" class="form-label fw-semibold small">Your Message / Order Requirement <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="message" name="message" rows="5" placeholder="Specify your flock quantity, required delivery dates, or technical questions..." required><?= htmlspecialchars($message) ?></textarea>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-farm-primary btn-lg py-3 fw-bold rounded-pill shadow-sm">
                            <i class="bi bi-send-fill me-2"></i> Submit Inquiry
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
