<?php
/**
 * Home Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'Organic Poultry, Fresh Eggs & Quality Feeds';
require_once __DIR__ . '/includes/header.php';

// Fetch featured products from database
$featured_products = [];
try {
    $pdo = get_db();
    $stmt = $pdo->query("SELECT p.*, c.name AS category_name FROM `products` p LEFT JOIN `categories` c ON p.category_id = c.id WHERE p.status = 'active' AND p.featured = 1 ORDER BY p.id ASC LIMIT 4");
    $featured_products = $stmt->fetchAll();

    // If fewer than 4 featured, fetch recent active products
    if (count($featured_products) < 4) {
        $stmt = $pdo->query("SELECT p.*, c.name AS category_name FROM `products` p LEFT JOIN `categories` c ON p.category_id = c.id WHERE p.status = 'active' ORDER BY p.id DESC LIMIT 4");
        $featured_products = $stmt->fetchAll();
    }
} catch (Exception $e) {
    // Graceful fallback if database not yet migrated
}
?>

<!-- HERO SECTION -->
<section class="hero-section">
    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center g-5">
            <div class="col-lg-7">
                <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-bold text-uppercase mb-3">
                    <i class="bi bi-patch-check-fill me-1"></i> Certified Biosecure Poultry Farm
                </span>
                <h1 class="display-4 fw-extrabold mb-3 text-white">
                    Fresh, Healthy & Organically Raised <span class="text-warning">Poultry</span> Direct From Our Hatchery
                </h1>
                <p class="lead text-white-50 mb-4 fs-5">
                    Order mature meat broilers, point-of-lay hens, vaccinated day-old chicks, farm-fresh eggs, and nutrition-dense feeds delivered swiftly to your doorstep or farm gate.
                </p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="/poultry/shop.php" class="btn btn-warning btn-lg px-4 py-3 fw-bold text-dark rounded-pill shadow-sm">
                        <i class="bi bi-cart3 me-2"></i> Shop Poultry Products
                    </a>
                    <a href="/poultry/services.php" class="btn btn-outline-light btn-lg px-4 py-3 fw-bold rounded-pill">
                        <i class="bi bi-shield-check me-2"></i> Explore Our Services
                    </a>
                </div>

                <!-- Live stats badges -->
                <div class="row g-3 mt-4 pt-2">
                    <div class="col-6 col-sm-4">
                        <div class="hero-stats-badge text-center text-sm-start">
                            <h3 class="fw-bold mb-0 text-warning">15,000+</h3>
                            <small class="text-white-50">Birds Raised Annually</small>
                        </div>
                    </div>
                    <div class="col-6 col-sm-4">
                        <div class="hero-stats-badge text-center text-sm-start">
                            <h3 class="fw-bold mb-0 text-warning">98.5%</h3>
                            <small class="text-white-50">Hatchability Rate</small>
                        </div>
                    </div>
                    <div class="col-12 col-sm-4">
                        <div class="hero-stats-badge text-center text-sm-start">
                            <h3 class="fw-bold mb-0 text-warning">4,200+</h3>
                            <small class="text-white-50">Happy Customers</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Hero Image / Feature Card -->
            <div class="col-lg-5 text-center">
                <div class="position-relative d-inline-block">
                    <img src="https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=700&q=80" alt="Poultry Farm" class="img-fluid rounded-4 shadow-lg border border-3 border-white border-opacity-25" style="max-height: 480px; object-fit: cover;">
                    <div class="position-absolute bottom-0 start-0 bg-white text-dark p-3 rounded-3 shadow m-3 text-start d-flex align-items-center gap-3">
                        <div class="bg-success text-white rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 44px; height: 44px;">
                            <i class="bi bi-truck fs-4"></i>
                        </div>
                        <div>
                            <p class="mb-0 fw-bold">Live Bird Delivery</p>
                            <small class="text-muted">Safe, ventilated delivery crates</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- HIGHLIGHTS BANNER -->
<section class="py-4 bg-white border-bottom shadow-sm">
    <div class="container">
        <div class="row g-4 text-center text-md-start">
            <div class="col-md-3 col-sm-6 d-flex align-items-center justify-content-center justify-content-md-start gap-3">
                <div class="bg-success bg-opacity-10 text-success rounded-circle p-3 fs-3">
                    <i class="bi bi-shield-check"></i>
                </div>
                <div>
                    <h6 class="fw-bold mb-0">100% Bio-Secure</h6>
                    <small class="text-muted">Strict vaccination protocols</small>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 d-flex align-items-center justify-content-center justify-content-md-start gap-3">
                <div class="bg-warning bg-opacity-10 text-warning rounded-circle p-3 fs-3">
                    <i class="bi bi-egg"></i>
                </div>
                <div>
                    <h6 class="fw-bold mb-0">Daily Fresh Harvest</h6>
                    <small class="text-muted">Organic table & fertile eggs</small>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 d-flex align-items-center justify-content-center justify-content-md-start gap-3">
                <div class="bg-primary bg-opacity-10 text-primary rounded-circle p-3 fs-3">
                    <i class="bi bi-truck"></i>
                </div>
                <div>
                    <h6 class="fw-bold mb-0">Direct Farm Delivery</h6>
                    <small class="text-muted">Fast & temperature-managed</small>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 d-flex align-items-center justify-content-center justify-content-md-start gap-3">
                <div class="bg-danger bg-opacity-10 text-danger rounded-circle p-3 fs-3">
                    <i class="bi bi-headset"></i>
                </div>
                <div>
                    <h6 class="fw-bold mb-0">Expert Vet Support</h6>
                    <small class="text-muted">Free poultry advice hotline</small>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FEATURED PRODUCTS SECTION -->
<section class="py-5">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-3 py-2 rounded-pill">
                    Farm Fresh Picks
                </span>
                <h2 class="fw-bold mt-2 mb-1">Featured Poultry & Products</h2>
                <p class="text-muted mb-0">Top quality birds, day-old chicks, and poultry supplies</p>
            </div>
            <a href="/poultry/shop.php" class="btn btn-outline-success fw-bold rounded-pill d-none d-md-inline-block">
                View All Catalog <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>

        <?php if (!empty($featured_products)): ?>
            <div class="row g-4">
                <?php foreach ($featured_products as $p): ?>
                    <div class="col-md-6 col-lg-3">
                        <div class="product-card">
                            <div class="product-image-container">
                                <img src="<?= htmlspecialchars($p['image_url'] ?? 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=600&q=80') ?>" alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
                                
                                <span class="product-badge-category">
                                    <?= htmlspecialchars($p['category_name'] ?? 'Poultry') ?>
                                </span>

                                <?php if ($p['stock_quantity'] > 10): ?>
                                    <span class="badge bg-success product-badge-stock">In Stock (<?= $p['stock_quantity'] ?>)</span>
                                <?php elseif ($p['stock_quantity'] > 0): ?>
                                    <span class="badge bg-warning text-dark product-badge-stock">Low Stock (<?= $p['stock_quantity'] ?>)</span>
                                <?php else: ?>
                                    <span class="badge bg-danger product-badge-stock">Out of Stock</span>
                                <?php endif; ?>
                            </div>

                            <div class="card-body">
                                <h5 class="card-title fw-bold mb-1 text-truncate" title="<?= htmlspecialchars($p['name']) ?>">
                                    <?= htmlspecialchars($p['name']) ?>
                                </h5>
                                <p class="text-muted small mb-3 flex-grow-1" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                    <?= htmlspecialchars($p['description'] ?? 'Quality farm fresh product.') ?>
                                </p>

                                <div class="d-flex justify-content-between align-items-baseline mb-3">
                                    <span class="product-price-tag"><?= format_currency($p['price']) ?></span>
                                    <span class="product-unit-tag"><?= htmlspecialchars($p['unit']) ?></span>
                                </div>

                                <div class="d-flex gap-2">
                                    <input type="number" class="form-control form-control-sm text-center qty-input" data-product-id="<?= $p['id'] ?>" value="1" min="1" max="<?= $p['stock_quantity'] ?>" style="width: 60px;" <?= $p['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                    <button class="btn btn-farm-primary btn-sm flex-grow-1 btn-add-to-cart" data-product-id="<?= $p['id'] ?>" <?= $p['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                        <i class="bi bi-cart-plus me-1"></i> Add to Cart
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center py-4">
                <i class="bi bi-info-circle fs-3 d-block mb-2"></i>
                <p class="mb-2">No featured products currently displayed.</p>
                <a href="/poultry/setup.php" class="btn btn-sm btn-primary">Initialize Database with Sample Products</a>
            </div>
        <?php endif; ?>

        <div class="text-center mt-4 d-md-none">
            <a href="/poultry/shop.php" class="btn btn-outline-success fw-bold rounded-pill w-100 py-2">
                View All Catalog <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>
    </div>
</section>

<!-- SERVICES PREVIEW -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center max-w-700 mx-auto mb-5">
            <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-3 py-2 rounded-pill">
                Comprehensive Solutions
            </span>
            <h2 class="fw-bold mt-2 mb-2">Our Poultry Farming Services</h2>
            <p class="text-muted">From modern hatchery incubation to specialized veterinary guidance and feeds</p>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-4">
                <div class="service-feature-card">
                    <div class="service-icon-box">
                        <i class="bi bi-brightness-high"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Day-Old Chicks Supply</h5>
                    <p class="text-muted small mb-3">
                        Commercial broiler chicks (Cobb 500, Ross 308) and high-yielding layer chicks vaccinated at our automated hatchery.
                    </p>
                    <a href="/poultry/services.php" class="text-success fw-bold text-decoration-none small">
                        Learn More <i class="bi bi-chevron-right"></i>
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="service-feature-card">
                    <div class="service-icon-box">
                        <i class="bi bi-egg-fried"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Table & Fertile Eggs</h5>
                    <p class="text-muted small mb-3">
                        Grade A organic table eggs gathered fresh every morning, alongside fertility-tested hatching eggs with high hatch rates.
                    </p>
                    <a href="/poultry/services.php" class="text-success fw-bold text-decoration-none small">
                        Learn More <i class="bi bi-chevron-right"></i>
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="service-feature-card">
                    <div class="service-icon-box">
                        <i class="bi bi-box-seam"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Custom Feed Formulation</h5>
                    <p class="text-muted small mb-3">
                        Balanced starter, grower, layer, and finisher feeds enriched with essential amino acids, calcium, and minerals.
                    </p>
                    <a href="/poultry/services.php" class="text-success fw-bold text-decoration-none small">
                        Learn More <i class="bi bi-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <a href="/poultry/services.php" class="btn btn-farm-primary px-4 py-2 rounded-pill fw-bold">
                View All Services & Consultancy <i class="bi bi-arrow-right ms-2"></i>
            </a>
        </div>
    </div>
</section>

<!-- WHY CHOOSE US -->
<section class="py-5">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <img src="https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=700&q=80" alt="Healthy Chickens" class="img-fluid rounded-4 shadow-lg">
            </div>
            <div class="col-lg-6">
                <span class="badge bg-warning bg-opacity-25 text-warning fw-bold text-uppercase px-3 py-2 rounded-pill text-dark mb-2">
                    Why Choose FeatherFarm
                </span>
                <h2 class="fw-bold mb-3">Raising Quality Poultry With Modern Biosecurity & Care</h2>
                <p class="text-muted mb-4">
                    We adhere to the highest international agricultural standards. Our birds are fed on 100% natural, antibiotic-free feeds in climate-optimized coops.
                </p>

                <div class="d-flex flex-column gap-3">
                    <div class="d-flex align-items-start gap-3">
                        <div class="bg-success text-white rounded-circle p-2 mt-1">
                            <i class="bi bi-check-lg fw-bold"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-1">Strict Veterinary Supervision</h6>
                            <p class="text-muted small mb-0">Every flock undergoes regular microbiological testing and full disease immunizations.</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start gap-3">
                        <div class="bg-success text-white rounded-circle p-2 mt-1">
                            <i class="bi bi-check-lg fw-bold"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-1">Fast & Reliable Supply Chain</h6>
                            <p class="text-muted small mb-0">Live bird delivery trucks and insulated egg carriers ensure zero transit stress and fresh delivery.</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start gap-3">
                        <div class="bg-success text-white rounded-circle p-2 mt-1">
                            <i class="bi bi-check-lg fw-bold"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-1">Transparent Pricing & Weight Guarantee</h6>
                            <p class="text-muted small mb-0">No hidden costs. Get verified live weight on all broilers and guaranteed crate egg counts.</p>
                        </div>
                    </div>
                </div>

                <div class="mt-4 pt-2">
                    <a href="/poultry/contact.php" class="btn btn-outline-success fw-bold px-4 py-2 rounded-pill">
                        <i class="bi bi-chat-dots me-2"></i> Contact Farm Team
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- TESTIMONIALS -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-3 py-2 rounded-pill">
                Client Feedback
            </span>
            <h2 class="fw-bold mt-2">What Poultry Farmers & Chefs Say</h2>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm rounded-4 p-4">
                    <div class="text-warning mb-3">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                    </div>
                    <p class="text-secondary small fst-italic flex-grow-1">
                        "The day-old broiler chicks arrived in perfect vigor. We had a 99% survival rate after 6 weeks and reached an average live weight of 2.5kg per bird."
                    </p>
                    <div class="d-flex align-items-center gap-3 pt-3 border-top">
                        <div class="brand-icon-box bg-success text-white" style="width: 40px; height: 40px; font-size: 1.1rem;">
                            <i class="bi bi-person"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">David Mwangi</h6>
                            <small class="text-muted">Commercial Poultry Farmer</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm rounded-4 p-4">
                    <div class="text-warning mb-3">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                    </div>
                    <p class="text-secondary small fst-italic flex-grow-1">
                        "We source 100 crates of organic eggs weekly for our bakery chain. The yolk quality and consistency are unmatched. Always punctual delivery!"
                    </p>
                    <div class="d-flex align-items-center gap-3 pt-3 border-top">
                        <div class="brand-icon-box bg-warning text-white" style="width: 40px; height: 40px; font-size: 1.1rem;">
                            <i class="bi bi-person"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">Elena Rostova</h6>
                            <small class="text-muted">Bakery Operations Director</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm rounded-4 p-4">
                    <div class="text-warning mb-3">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                    </div>
                    <p class="text-secondary small fst-italic flex-grow-1">
                        "FeatherFarm's order tracking made keeping tabs on our feed and point-of-lay pullets straightforward. Great customer support and clean biosecurity."
                    </p>
                    <div class="d-flex align-items-center gap-3 pt-3 border-top">
                        <div class="brand-icon-box bg-primary text-white" style="width: 40px; height: 40px; font-size: 1.1rem;">
                            <i class="bi bi-person"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">Marcus Thorne</h6>
                            <small class="text-muted">Agro-Entrepreneur</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CALL TO ACTION BANNER -->
<section class="py-5 bg-success text-white text-center">
    <div class="container py-3">
        <h2 class="display-6 fw-bold mb-3">Ready to Place Your Poultry Order?</h2>
        <p class="lead text-white-50 max-w-700 mx-auto mb-4 fs-5">
            Browse our catalog for mature broilers, layers, hatching eggs, and high-protein feeds with doorstep delivery.
        </p>
        <div class="d-flex justify-content-center gap-3">
            <a href="/poultry/shop.php" class="btn btn-warning btn-lg px-4 py-3 fw-bold text-dark rounded-pill shadow">
                <i class="bi bi-bag-check-fill me-2"></i> Browse & Buy Now
            </a>
            <a href="/poultry/contact.php" class="btn btn-outline-light btn-lg px-4 py-3 rounded-pill fw-bold">
                <i class="bi bi-telephone me-2"></i> Call Farm Rep
            </a>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
