<?php
/**
 * Global Footer Template
 * FeatherFarm Poultry Management System
 */

require_once __DIR__ . '/functions.php';

$farm_name = get_setting('farm_name', 'FeatherFarm Poultry');
?>
<!-- FOOTER -->
<footer class="bg-dark text-white pt-5 pb-4 mt-5 border-top border-secondary border-opacity-25">
    <div class="container">
        <div class="row g-4">
            <!-- Col 1: Brand & About -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center mb-3">
                    <div class="brand-icon-box me-2" style="width: 40px; height: 40px; font-size: 1.2rem;">
                        <i class="bi bi-egg-fried"></i>
                    </div>
                    <span class="fs-4 fw-bold text-success">Feather<span class="text-warning">Farm</span></span>
                </div>
                <p class="text-secondary small mb-3">
                    <?= htmlspecialchars(get_setting('farm_tagline', 'Fresh, Healthy & Organically Raised Poultry Direct From Our Hatchery')) ?>. We guarantee certified biosecurity, high hatching success, and swift farm-to-table delivery.
                </p>
                <div class="d-flex gap-2 text-secondary">
                    <a href="#" class="btn btn-outline-secondary btn-sm rounded-circle text-white"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="btn btn-outline-secondary btn-sm rounded-circle text-white"><i class="bi bi-twitter-x"></i></a>
                    <a href="#" class="btn btn-outline-secondary btn-sm rounded-circle text-white"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="btn btn-outline-secondary btn-sm rounded-circle text-white"><i class="bi bi-whatsapp"></i></a>
                </div>
            </div>

            <!-- Col 2: Quick Links -->
            <div class="col-lg-2 col-md-6">
                <h6 class="text-uppercase fw-bold text-warning mb-3">Quick Links</h6>
                <ul class="list-unstyled small mb-0 d-flex flex-column gap-2">
                    <li><a href="/poultry/index.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right text-success small me-1"></i> Home</a></li>
                    <li><a href="/poultry/services.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right text-success small me-1"></i> Our Services</a></li>
                    <li><a href="/poultry/shop.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right text-success small me-1"></i> Buy Poultry</a></li>
                    <li><a href="/poultry/contact.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right text-success small me-1"></i> Contact Us</a></li>
                    <li><a href="/poultry/customer/my-orders.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right text-success small me-1"></i> Order Tracking</a></li>
                </ul>
            </div>

            <!-- Col 3: Poultry Categories -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-uppercase fw-bold text-warning mb-3">Our Offerings</h6>
                <ul class="list-unstyled small mb-0 d-flex flex-column gap-2">
                    <li><a href="/poultry/shop.php?category=broilers" class="text-secondary text-decoration-none hover-white"><i class="bi bi-tag text-success me-2"></i>Table Broilers</a></li>
                    <li><a href="/poultry/shop.php?category=layers" class="text-secondary text-decoration-none hover-white"><i class="bi bi-tag text-success me-2"></i>Point of Lay Hens</a></li>
                    <li><a href="/poultry/shop.php?category=day-old-chicks" class="text-secondary text-decoration-none hover-white"><i class="bi bi-tag text-success me-2"></i>Day-Old Chicks</a></li>
                    <li><a href="/poultry/shop.php?category=fresh-eggs" class="text-secondary text-decoration-none hover-white"><i class="bi bi-tag text-success me-2"></i>Organic Table & Hatching Eggs</a></li>
                    <li><a href="/poultry/shop.php?category=poultry-feeds" class="text-secondary text-decoration-none hover-white"><i class="bi bi-tag text-success me-2"></i>High Protein Poultry Feeds</a></li>
                </ul>
            </div>

            <!-- Col 4: Contact & Location -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-uppercase fw-bold text-warning mb-3">Farm Contact</h6>
                <ul class="list-unstyled small mb-0 d-flex flex-column gap-2 text-secondary">
                    <li class="d-flex align-items-start">
                        <i class="bi bi-geo-alt-fill text-success fs-5 me-2 mt-n1"></i>
                        <span><?= htmlspecialchars(get_setting('address', 'Plot 42 Green Valley Rd, CA')) ?></span>
                    </li>
                    <li class="d-flex align-items-center">
                        <i class="bi bi-telephone-fill text-success me-2"></i>
                        <span><?= htmlspecialchars(get_setting('phone', '+1 (555) 789-2345')) ?></span>
                    </li>
                    <li class="d-flex align-items-center">
                        <i class="bi bi-envelope-fill text-success me-2"></i>
                        <span><?= htmlspecialchars(get_setting('email', 'info@poultryfarm.com')) ?></span>
                    </li>
                    <li class="d-flex align-items-center">
                        <i class="bi bi-clock-fill text-success me-2"></i>
                        <span><?= htmlspecialchars(get_setting('working_hours', 'Mon - Sat: 7am - 6pm')) ?></span>
                    </li>
                </ul>
            </div>
        </div>

        <hr class="border-secondary border-opacity-25 my-4">

        <div class="row align-items-center small text-secondary">
            <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                &copy; <?= date('Y') ?> <strong><?= htmlspecialchars($farm_name) ?></strong>. All Rights Reserved.
            </div>
            <div class="col-md-6 text-center text-md-end">
                <span class="me-3"><i class="bi bi-shield-lock text-success me-1"></i> Biosecurity Certified</span>
                <span><i class="bi bi-truck text-warning me-1"></i> Farm-to-Door Delivery</span>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5.3 Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JavaScript Application -->
<script src="/poultry/assets/js/main.js"></script>

</body>
</html>
