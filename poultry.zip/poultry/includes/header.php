<?php
/**
 * Global Header & Navigation Template
 * FeatherFarm Poultry Management System
 */

require_once __DIR__ . '/functions.php';

$current_page = basename($_SERVER['PHP_SELF'] ?? '');
$farm_name = get_setting('farm_name', 'FeatherFarm Poultry');
$currency = get_setting('currency', '$');
$cart_count = get_cart_count();
$user = current_user();
$flash = get_flash_message();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' : '' ?><?= htmlspecialchars($farm_name) ?></title>
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="/poultry/assets/css/style.css">
    
    <style>
        body {
            font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
        }
    </style>
</head>
<body data-currency="<?= htmlspecialchars($currency) ?>">

<!-- TOP UTILITY BAR -->
<div class="bg-dark text-white py-2 small d-none d-md-block border-bottom border-secondary border-opacity-25">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-3">
            <span><i class="bi bi-geo-alt-fill text-warning me-1"></i> <?= htmlspecialchars(get_setting('address', 'Poultry Farm Valley, CA')) ?></span>
            <span><i class="bi bi-clock-fill text-warning me-1"></i> <?= htmlspecialchars(get_setting('working_hours', 'Mon-Sat: 7am - 6pm')) ?></span>
        </div>
        <div class="d-flex align-items-center gap-3">
            <span><i class="bi bi-telephone-fill text-warning me-1"></i> Helpline: <a href="tel:<?= htmlspecialchars(get_setting('phone', '+15557892345')) ?>" class="text-white text-decoration-none fw-bold"><?= htmlspecialchars(get_setting('phone', '+1 (555) 789-2345')) ?></a></span>
            <span class="text-secondary">|</span>
            <?php if (is_admin()): ?>
                <a href="/poultry/admin/index.php" class="badge bg-warning text-dark text-decoration-none py-1 px-2">
                    <i class="bi bi-speedometer2 me-1"></i> Admin Panel
                </a>
            <?php else: ?>
                <a href="/poultry/setup.php" class="text-secondary text-decoration-none small hover-light" title="Database setup & test accounts">
                    <i class="bi bi-database me-1"></i> DB Setup
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- MAIN NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-farm sticky-top">
    <div class="container">
        <!-- Brand Logo -->
        <a class="navbar-brand d-flex align-items-center" href="/poultry/index.php">
            <div class="brand-icon-box me-2">
                <i class="bi bi-egg-fried"></i>
            </div>
            <div>
                <span class="fs-4 fw-bold text-success d-block lh-1">Feather<span class="text-warning">Farm</span></span>
                <span class="text-muted small" style="font-size: 0.65rem; letter-spacing: 0.5px; text-transform: uppercase; font-weight: 700;">Poultry Management</span>
            </div>
        </a>

        <!-- Mobile Toggler & Mobile Cart -->
        <div class="d-flex align-items-center d-lg-none gap-2">
            <a href="/poultry/cart.php" class="btn btn-outline-success position-relative p-2 rounded-circle">
                <i class="bi bi-cart3 fs-5"></i>
                <span class="badge bg-danger cart-badge cart-count-badge <?= $cart_count > 0 ? '' : 'd-none' ?>">
                    <?= $cart_count ?>
                </span>
            </a>
            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <i class="bi bi-list fs-2 text-success"></i>
            </button>
        </div>

        <!-- Collapsible Navigation -->
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 fw-semibold">
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'index.php') ? 'active' : '' ?>" href="/poultry/index.php">
                        <i class="bi bi-house me-1"></i> Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'services.php') ? 'active' : '' ?>" href="/poultry/services.php">
                        <i class="bi bi-shield-check me-1"></i> Our Services
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'shop.php') ? 'active' : '' ?>" href="/poultry/shop.php">
                        <i class="bi bi-grid-fill me-1"></i> Buy Poultry & Products
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'contact.php') ? 'active' : '' ?>" href="/poultry/contact.php">
                        <i class="bi bi-envelope me-1"></i> Contact Us
                    </a>
                </li>
                <?php if (is_logged_in()): ?>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'my-orders.php') ? 'active' : '' ?>" href="/poultry/customer/my-orders.php">
                        <i class="bi bi-truck me-1"></i> Order Status
                    </a>
                </li>
                <?php endif; ?>
            </ul>

            <!-- Right Controls: Cart & Account -->
            <div class="d-flex align-items-center gap-3">
                <!-- Cart Button (Desktop) -->
                <a href="/poultry/cart.php" class="btn btn-outline-success position-relative d-none d-lg-inline-flex align-items-center gap-2 px-3 py-2 rounded-pill">
                    <i class="bi bi-cart3 fs-5"></i>
                    <span class="fw-bold">Cart</span>
                    <span class="badge bg-danger rounded-pill cart-count-badge <?= $cart_count > 0 ? '' : 'd-none' ?>">
                        <?= $cart_count ?>
                    </span>
                </a>

                <!-- User Authentication State -->
                <?php if (is_logged_in()): ?>
                    <div class="dropdown">
                        <button class="btn btn-farm-primary dropdown-toggle rounded-pill px-3 py-2 d-flex align-items-center gap-2" type="button" id="userMenuDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle fs-5"></i>
                            <span class="d-none d-sm-inline"><?= htmlspecialchars(explode(' ', $user['full_name'])[0]) ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3 mt-2" aria-labelledby="userMenuDropdown">
                            <li class="px-3 py-2 border-bottom">
                                <p class="mb-0 fw-bold"><?= htmlspecialchars($user['full_name']) ?></p>
                                <p class="mb-0 small text-muted"><?= htmlspecialchars($user['email']) ?></p>
                                <span class="badge <?= $user['role'] === 'admin' ? 'bg-danger' : 'bg-success' ?> mt-1">
                                    <?= ucfirst($user['role']) ?>
                                </span>
                            </li>
                            <?php if (is_admin()): ?>
                                <li>
                                    <a class="dropdown-item py-2 fw-semibold text-danger" href="/poultry/admin/index.php">
                                        <i class="bi bi-speedometer2 me-2"></i> Admin Dashboard
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <a class="dropdown-item py-2" href="/poultry/customer/my-orders.php">
                                    <i class="bi bi-box-seam me-2"></i> My Orders & Status
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item py-2 text-danger" href="/poultry/auth/logout.php">
                                    <i class="bi bi-box-arrow-right me-2"></i> Sign Out
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <div class="d-flex gap-2">
                        <a href="/poultry/auth/login.php" class="btn btn-outline-success rounded-pill px-3 py-2 fw-semibold">
                            <i class="bi bi-box-arrow-in-right me-1"></i> Login
                        </a>
                        <a href="/poultry/auth/register.php" class="btn btn-farm-primary rounded-pill px-3 py-2">
                            <i class="bi bi-person-plus me-1"></i> Register
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- FLASH MESSAGE NOTIFICATIONS -->
<?php if ($flash): ?>
    <div class="container mt-3">
        <div class="alert alert-<?= htmlspecialchars($flash['type']) ?> alert-dismissible fade show shadow-sm d-flex align-items-center" role="alert">
            <i class="bi <?= $flash['type'] === 'success' ? 'bi-check-circle-fill' : ($flash['type'] === 'danger' ? 'bi-exclamation-triangle-fill' : 'bi-info-circle-fill') ?> fs-4 me-3"></i>
            <div>
                <?= $flash['message'] ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>
