<?php
/**
 * Global Helper Functions & Session Handler
 * FeatherFarm Poultry Management System
 */

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

/**
 * Clean & sanitize user input
 */
function clean_input($data) {
    return htmlspecialchars(trim($data ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Set a flash message to display on the next page
 */
function set_flash_message($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Retrieve and clear flash message
 */
function get_flash_message() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Check if a user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user']) && !empty($_SESSION['user']['id']);
}

/**
 * Get current logged in user array
 */
function current_user() {
    return $_SESSION['user'] ?? null;
}

/**
 * Check if the logged in user is an administrator
 */
function is_admin() {
    return is_logged_in() && isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'admin';
}

/**
 * Require customer/user authentication
 */
function require_login($redirect = null) {
    if (!is_logged_in()) {
        $target = $redirect ?? $_SERVER['REQUEST_URI'] ?? '/auth/login.php';
        $_SESSION['redirect_after_login'] = $target;
        set_flash_message('warning', 'Please sign in to access that page.');
        header('Location: /poultry/auth/login.php');
        exit;
    }
}

/**
 * Require administrator authentication
 */
function require_admin() {
    if (!is_admin()) {
        set_flash_message('danger', 'Access denied. Administrator privileges required.');
        header('Location: /poultry/auth/login.php');
        exit;
    }
}

/**
 * Fetch a store setting from the database or return default
 */
function get_setting($key, $default = '') {
    static $settings_cache = null;
    if ($settings_cache === null) {
        $settings_cache = [];
        try {
            $pdo = get_db();
            $stmt = $pdo->query("SELECT `setting_key`, `setting_value` FROM `settings`");
            while ($row = $stmt->fetch()) {
                $settings_cache[$row['setting_key']] = $row['setting_value'];
            }
        } catch (Exception $e) {
            // Table may not exist yet if before setup
        }
    }
    return $settings_cache[$key] ?? $default;
}

/**
 * Format currency with configured symbol
 */
function format_currency($amount) {
    $symbol = get_setting('currency', '$');
    return $symbol . number_format((float)$amount, 2);
}

/**
 * Generate a unique, professional Order Number
 */
function generate_order_number() {
    return 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
}

// ----------------------------------------------------
// Shopping Cart Session Management
// ----------------------------------------------------

/**
 * Initialize cart session array if not present
 */
function init_cart() {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
}

/**
 * Get all cart items with product details fetched from database
 */
function get_cart_items() {
    init_cart();
    if (empty($_SESSION['cart'])) {
        return [];
    }

    $product_ids = array_keys($_SESSION['cart']);
    if (empty($product_ids)) {
        return [];
    }

    try {
        $pdo = get_db();
        $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
        $stmt = $pdo->prepare("SELECT p.*, c.name AS category_name FROM `products` p LEFT JOIN `categories` c ON p.category_id = c.id WHERE p.id IN ($placeholders) AND p.status = 'active'");
        $stmt->execute($product_ids);
        $products = $stmt->fetchAll();

        $items = [];
        foreach ($products as $prod) {
            $pid = $prod['id'];
            $qty = (int)($_SESSION['cart'][$pid] ?? 0);
            if ($qty > 0) {
                // Ensure quantity doesn't exceed stock
                $qty = min($qty, (int)$prod['stock_quantity']);
                $subtotal = $qty * (float)$prod['price'];
                $items[] = [
                    'product_id' => $prod['id'],
                    'name' => $prod['name'],
                    'slug' => $prod['slug'],
                    'category' => $prod['category_name'],
                    'price' => (float)$prod['price'],
                    'unit' => $prod['unit'],
                    'image_url' => $prod['image_url'],
                    'stock' => (int)$prod['stock_quantity'],
                    'quantity' => $qty,
                    'subtotal' => $subtotal
                ];
            }
        }
        return $items;
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Calculate total quantity of items in cart
 */
function get_cart_count() {
    init_cart();
    $count = 0;
    foreach ($_SESSION['cart'] as $qty) {
        $count += (int)$qty;
    }
    return $count;
}

/**
 * Calculate subtotal of items in cart
 */
function get_cart_subtotal() {
    $items = get_cart_items();
    $subtotal = 0.0;
    foreach ($items as $item) {
        $subtotal += $item['subtotal'];
    }
    return $subtotal;
}

/**
 * Get delivery fee based on threshold and subtotal
 */
function get_delivery_fee($subtotal = null) {
    if ($subtotal === null) {
        $subtotal = get_cart_subtotal();
    }
    if ($subtotal <= 0) {
        return 0.0;
    }
    $free_threshold = (float)get_setting('free_delivery_threshold', '100.00');
    if ($subtotal >= $free_threshold) {
        return 0.0;
    }
    return (float)get_setting('delivery_fee', '5.00');
}

/**
 * Get grand total (subtotal + delivery fee)
 */
function get_cart_grand_total() {
    $subtotal = get_cart_subtotal();
    if ($subtotal <= 0) {
        return 0.0;
    }
    return $subtotal + get_delivery_fee($subtotal);
}
