<?php
/**
 * Automated 1-Click Database Setup & Migrator
 * FeatherFarm Poultry Management System
 */

$status = null;
$message = '';
$details = [];

// Default connection parameters
$host = $_POST['host'] ?? 'localhost';
$user = $_POST['user'] ?? 'root';
$pass = $_POST['pass'] ?? '';
$dbname = $_POST['dbname'] ?? 'poultry_db';

if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['auto'])) {
    try {
        // 1. Connect to MySQL Server (without selecting database yet)
        $dsn = "mysql:host={$host};charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        $details[] = "Connected successfully to MySQL server at <strong>{$host}</strong>.";

        // 2. Create Database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbname}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $details[] = "Database <strong>{$dbname}</strong> created or verified.";

        // 3. Switch to the database
        $pdo->exec("USE `{$dbname}`");

        // 4. Read schema.sql
        $schema_path = __DIR__ . '/database/schema.sql';
        if (!file_exists($schema_path)) {
            throw new Exception("schema.sql not found at: {$schema_path}");
        }

        $sql = file_get_contents($schema_path);

        // Remove USE and CREATE DATABASE statements because we've handled them dynamically
        // Split queries by semicolon followed by newline
        $pdo->exec($sql);
        $details[] = "Schema executed successfully. All tables (users, categories, products, orders, order_items, contact_messages, settings) created.";

        // 5. Set default passwords (plain text for admin as requested)
        $stmt = $pdo->prepare("UPDATE `users` SET `password` = 'admin123' WHERE `email` = 'admin@poultryfarm.com'");
        $stmt->execute();

        $stmt = $pdo->prepare("UPDATE `users` SET `password` = 'customer123' WHERE `email` = 'customer@poultryfarm.com'");
        $stmt->execute();

        $details[] = "Admin account calibrated with plain text unhashed password: <code>admin123</code>.";
        $details[] = "Sample poultry stock, egg batches, feeds, categories, and store settings successfully seeded.";

        $status = 'success';
        $message = "Database initialization completed successfully!";
    } catch (Exception $e) {
        $status = 'error';
        $message = "Setup error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FeatherFarm - Database Setup Wizard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0f7f2 0%, #e2efe6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        .setup-card {
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(46, 125, 50, 0.12);
            border: none;
        }
        .header-badge {
            background-color: #2e7d32;
            color: #fff;
            width: 64px;
            height: 64px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            margin-bottom: 16px;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-7 col-md-9">
            <div class="card setup-card p-4 p-md-5">
                <div class="text-center">
                    <div class="header-badge">
                        <i class="bi bi-egg-fried"></i>
                    </div>
                    <h2 class="fw-bold text-success mb-1">FeatherFarm Setup Wizard</h2>
                    <p class="text-muted">Poultry Management & E-Commerce System Database Installer</p>
                </div>

                <?php if ($status === 'success'): ?>
                    <div class="alert alert-success d-flex align-items-center mt-3" role="alert">
                        <i class="bi bi-check-circle-fill fs-3 me-3 text-success"></i>
                        <div>
                            <h5 class="alert-heading mb-1 fw-bold"><?= $message ?></h5>
                            <p class="mb-0 small">Database <strong><?= htmlspecialchars($dbname) ?></strong> is ready and populated.</p>
                        </div>
                    </div>

                    <div class="card bg-light border-0 mb-4">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3 text-secondary"><i class="bi bi-list-check me-2"></i>Actions Executed:</h6>
                            <ul class="list-unstyled mb-0 small">
                                <?php foreach ($details as $d): ?>
                                    <li class="mb-2"><i class="bi bi-check2 text-success me-2 fw-bold"></i><?= $d ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>

                    <div class="card border-warning mb-4">
                        <div class="card-header bg-warning bg-opacity-25 fw-bold text-dark">
                            <i class="bi bi-shield-lock-fill me-2"></i>Default Login Credentials
                        </div>
                        <div class="card-body py-3">
                            <div class="row">
                                <div class="col-md-6 mb-3 mb-md-0 border-end">
                                    <span class="badge bg-danger mb-1">Administrator Access</span>
                                    <p class="mb-1 small"><strong>Email:</strong> <code>admin@poultryfarm.com</code></p>
                                    <p class="mb-0 small"><strong>Password:</strong> <code>admin123</code></p>
                                </div>
                                <div class="col-md-6">
                                    <span class="badge bg-success mb-1">Customer Demo Account</span>
                                    <p class="mb-1 small"><strong>Email:</strong> <code>customer@poultryfarm.com</code></p>
                                    <p class="mb-0 small"><strong>Password:</strong> <code>customer123</code></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-between">
                        <a href="index.php" class="btn btn-outline-success px-4 py-2">
                            <i class="bi bi-house-door me-2"></i>View Home Page
                        </a>
                        <a href="shop.php" class="btn btn-outline-primary px-4 py-2">
                            <i class="bi bi-bag-check me-2"></i>Buy Poultry Store
                        </a>
                        <a href="admin/index.php" class="btn btn-success px-4 py-2">
                            <i class="bi bi-speedometer2 me-2"></i>Admin Dashboard
                        </a>
                    </div>

                <?php else: ?>
                    <?php if ($status === 'error'): ?>
                        <div class="alert alert-danger d-flex align-items-center mt-3" role="alert">
                            <i class="bi bi-exclamation-triangle-fill fs-3 me-3 text-danger"></i>
                            <div>
                                <h6 class="alert-heading mb-1 fw-bold">Setup Failed</h6>
                                <p class="mb-0 small"><?= htmlspecialchars($message) ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <p class="text-secondary small mt-3">
                        This automated wizard creates the <code>poultry_db</code> database in MySQL and sets up all required tables, product inventories, categories, order tables, and admin accounts.
                    </p>

                    <form method="POST" action="setup.php" class="mt-4">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">MySQL Host</label>
                                <input type="text" name="host" class="form-control" value="<?= htmlspecialchars($host) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Database Name</label>
                                <input type="text" name="dbname" class="form-control" value="<?= htmlspecialchars($dbname) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">MySQL Username</label>
                                <input type="text" name="user" class="form-control" value="<?= htmlspecialchars($user) ?>" required>
                                <div class="form-text">Default in XAMPP/WAMP is usually <code>root</code>.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">MySQL Password</label>
                                <input type="password" name="pass" class="form-control" value="<?= htmlspecialchars($pass) ?>" placeholder="Leave blank if no password">
                                <div class="form-text">Default in XAMPP is empty.</div>
                            </div>
                        </div>

                        <div class="mt-4 d-grid">
                            <button type="submit" class="btn btn-success btn-lg py-3 fw-bold shadow-sm">
                                <i class="bi bi-play-circle-fill me-2"></i>Install Database & Seed Data Now
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
            <div class="text-center mt-3 text-muted small">
                FeatherFarm Poultry Management System &copy; <?= date('Y') ?>. Responsive & Secure.
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
