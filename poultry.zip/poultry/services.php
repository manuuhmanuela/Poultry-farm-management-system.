<?php
/**
 * Our Services Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'Our Services';
require_once __DIR__ . '/includes/header.php';
?>

<!-- SERVICES HERO -->
<section class="bg-success text-white py-5">
    <div class="container text-center py-4">
        <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-bold text-uppercase mb-3">
            Expert Agriculture Services
        </span>
        <h1 class="display-5 fw-bold mb-3">Professional Poultry Farm Services</h1>
        <p class="lead text-white-50 max-w-700 mx-auto">
            From modern automated hatchery incubation to custom nutrition formulation and farm biosecurity consultancy.
        </p>
    </div>
</section>

<!-- SERVICES DETAIL CARDS -->
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Service 1: Day-Old Chicks Supply -->
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1563281577-a7be47e20db9?auto=format&fit=crop&w=600&q=80" class="card-img-top" alt="Day-Old Chicks" style="height: 220px; object-fit: cover;">
                    <div class="card-body p-4 d-flex flex-direction-column">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-warning text-dark"><i class="bi bi-patch-check"></i> Hatchery Certified</span>
                        </div>
                        <h4 class="fw-bold mb-2">Day-Old Chicks Production</h4>
                        <p class="text-muted small mb-4 flex-grow-1">
                            We operate advanced multi-stage automated incubators with precision humidity and temperature control. We hatch commercial broilers (Cobb 500, Ross 308) and high-producing layer pullets with high livability.
                        </p>
                        <ul class="list-unstyled small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Marek's & Newcastle vaccinated</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Strict genetic parent stock</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Ventilated delivery crates</li>
                        </ul>
                        <div class="d-grid mt-auto">
                            <a href="/poultry/shop.php?category=day-old-chicks" class="btn btn-outline-success fw-bold py-2 rounded-pill">
                                Buy Day-Old Chicks <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Service 2: Broiler & Layer Rearing -->
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=600&q=80" class="card-img-top" alt="Broiler & Layer Farming" style="height: 220px; object-fit: cover;">
                    <div class="card-body p-4 d-flex flex-direction-column">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-success"><i class="bi bi-feather"></i> 100% Organic Raised</span>
                        </div>
                        <h4 class="fw-bold mb-2">Broiler & Layer Rearing</h4>
                        <p class="text-muted small mb-4 flex-grow-1">
                            We raise healthy, free-roaming and deep-litter broiler chickens ready for meat processing, alongside point-of-lay pullets ready to begin laying eggs immediately upon delivery.
                        </p>
                        <ul class="list-unstyled small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Broilers: 2.2kg - 2.8kg mature weight</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Layers: 18-week point of lay pullets</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Antibiotic residue free</li>
                        </ul>
                        <div class="d-grid mt-auto">
                            <a href="/poultry/shop.php?category=broilers" class="btn btn-outline-success fw-bold py-2 rounded-pill">
                                Order Live Birds <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Service 3: Custom Feed Formulation -->
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1628102491629-778571d893a3?auto=format&fit=crop&w=600&q=80" class="card-img-top" alt="Poultry Feed" style="height: 220px; object-fit: cover;">
                    <div class="card-body p-4 d-flex flex-direction-column">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-primary"><i class="bi bi-box-seam"></i> Nutrition Rich</span>
                        </div>
                        <h4 class="fw-bold mb-2">Nutrition & Feed Milling</h4>
                        <p class="text-muted small mb-4 flex-grow-1">
                            Scientifically formulated poultry feeds manufactured from premium grains, soybean meal, fish meal, premixes, and essential minerals to maximize feed conversion ratio (FCR).
                        </p>
                        <ul class="list-unstyled small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Broiler Starter, Grower & Finisher</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Layer Mash & Chick Mash</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Custom formulations for large farms</li>
                        </ul>
                        <div class="d-grid mt-auto">
                            <a href="/poultry/shop.php?category=poultry-feeds" class="btn btn-outline-success fw-bold py-2 rounded-pill">
                                Browse Feeds <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Service 4: Veterinary Advisory & Vaccination -->
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=600&q=80" class="card-img-top" alt="Veterinary Service" style="height: 220px; object-fit: cover;">
                    <div class="card-body p-4 d-flex flex-direction-column">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-danger"><i class="bi bi-heart-pulse"></i> Vet Certified</span>
                        </div>
                        <h4 class="fw-bold mb-2">Veterinary & Vaccination Care</h4>
                        <p class="text-muted small mb-4 flex-grow-1">
                            Our team of certified veterinary doctors and poultry technicians provide on-farm diagnostics, vaccination scheduling (Gumboro, Lasota, Fowl Pox), and biosecurity audits.
                        </p>
                        <ul class="list-unstyled small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Disease diagnosis & post-mortem analysis</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Customized flock vaccination schedules</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Farm disinfection & pest control plans</li>
                        </ul>
                        <div class="d-grid mt-auto">
                            <a href="/poultry/contact.php?subject=Veterinary%20Consultancy" class="btn btn-outline-success fw-bold py-2 rounded-pill">
                                Request Vet Assistance <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Service 5: Poultry Equipment & Battery Cages -->
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=600&q=80" class="card-img-top" alt="Poultry Equipment" style="height: 220px; object-fit: cover;">
                    <div class="card-body p-4 d-flex flex-direction-column">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-secondary"><i class="bi bi-tools"></i> Farm Setup</span>
                        </div>
                        <h4 class="fw-bold mb-2">Equipment & Battery Cages</h4>
                        <p class="text-muted small mb-4 flex-grow-1">
                            Turnkey supply and installation of commercial A-frame battery cages, nipple drinker systems, automated hopper feeders, brooder heaters, and ventilation fan systems.
                        </p>
                        <ul class="list-unstyled small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Galvanized rust-resistant cages</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Automatic water medication systems</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Infrared heating lamps & thermometers</li>
                        </ul>
                        <div class="d-grid mt-auto">
                            <a href="/poultry/shop.php?category=equipment-care" class="btn btn-outline-success fw-bold py-2 rounded-pill">
                                View Farm Equipment <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Service 6: Wholesale & Restaurant Logistics -->
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&w=600&q=80" class="card-img-top" alt="Wholesale Eggs" style="height: 220px; object-fit: cover;">
                    <div class="card-body p-4 d-flex flex-direction-column">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-info text-dark"><i class="bi bi-truck"></i> Wholesale</span>
                        </div>
                        <h4 class="fw-bold mb-2">Bulk Wholesale Supply</h4>
                        <p class="text-muted small mb-4 flex-grow-1">
                            Reliable bulk contracts for hotels, supermarkets, restaurants, and schools. Enjoy contracted wholesale discounts, scheduled daily or weekly deliveries, and consistent supply.
                        </p>
                        <ul class="list-unstyled small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Crated eggs (50 to 1,000+ crates weekly)</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Dressed or live broilers in bulk batches</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Flexible credit terms for verified businesses</li>
                        </ul>
                        <div class="d-grid mt-auto">
                            <a href="/poultry/contact.php?subject=Wholesale%20Contract%20Inquiry" class="btn btn-outline-success fw-bold py-2 rounded-pill">
                                Inquire For Wholesale <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CONSULTANCY BANNER -->
<section class="py-5 bg-light border-top">
    <div class="container">
        <div class="row align-items-center bg-white p-4 p-md-5 rounded-4 shadow-sm border">
            <div class="col-lg-8">
                <h3 class="fw-bold mb-2">Starting or Expanding Your Poultry Farm?</h3>
                <p class="text-muted mb-0">
                    Book a consultation with our senior poultry farm manager. We help with site feasibility studies, coop blueprint design, flock budgeting, and feed conversion maximization.
                </p>
            </div>
            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                <a href="/poultry/contact.php?subject=Poultry%20Consultation" class="btn btn-farm-primary btn-lg px-4 py-3 rounded-pill fw-bold">
                    <i class="bi bi-calendar2-check me-2"></i> Book Farm Advisory
                </a>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
