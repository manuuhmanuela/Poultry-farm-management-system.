<?php
/**
 * AJAX Cart Actions Endpoint
 * FeatherFarm Poultry Management System
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/functions.php';

$response = [
    'success' => false,
    'message' => 'Invalid action',
    'cart_count' => 0
];

$action = $_REQUEST['action'] ?? '';
$product_id = isset($_REQUEST['product_id']) ? (int)$_REQUEST['product_id'] : 0;
$quantity = isset($_REQUEST['quantity']) ? (int)$_REQUEST['quantity'] : 1;

init_cart();

try {
    $pdo = get_db();

    if ($action === 'add') {
        if ($product_id <= 0) {
            throw new Exception("Invalid product selected.");
        }

        // Verify product in database and check stock
        $stmt = $pdo->prepare("SELECT `id`, `name`, `price`, `stock_quantity`, `status` FROM `products` WHERE `id` = ?");
        $stmt->execute([$product_id]);
        $prod = $stmt->fetch();

        if (!$prod || $prod['status'] !== 'active') {
            throw new Exception("Product is currently unavailable.");
        }

        $current_qty = $_SESSION['cart'][$product_id] ?? 0;
        $new_qty = $current_qty + max(1, $quantity);

        if ($new_qty > $prod['stock_quantity']) {
            $new_qty = (int)$prod['stock_quantity'];
            $response['warning'] = "Adjusted quantity to maximum available stock (" . $prod['stock_quantity'] . ").";
        }

        if ($new_qty <= 0) {
            throw new Exception("This product is currently out of stock.");
        }

        $_SESSION['cart'][$product_id] = $new_qty;

        $response['success'] = true;
        $response['message'] = "Added <strong>" . htmlspecialchars($prod['name']) . "</strong> to cart!";
        $response['product_id'] = $product_id;
        $response['quantity'] = $new_qty;
    }
    elseif ($action === 'update') {
        if ($product_id <= 0) {
            throw new Exception("Invalid product.");
        }

        if ($quantity <= 0) {
            unset($_SESSION['cart'][$product_id]);
            $response['message'] = "Item removed from cart.";
        } else {
            // Check stock limit
            $stmt = $pdo->prepare("SELECT `name`, `stock_quantity` FROM `products` WHERE `id` = ?");
            $stmt->execute([$product_id]);
            $prod = $stmt->fetch();

            if ($prod) {
                $quantity = min($quantity, (int)$prod['stock_quantity']);
                $_SESSION['cart'][$product_id] = $quantity;
                $response['message'] = "Cart updated.";
            } else {
                unset($_SESSION['cart'][$product_id]);
            }
        }
        $response['success'] = true;
    }
    elseif ($action === 'remove') {
        if (isset($_SESSION['cart'][$product_id])) {
            unset($_SESSION['cart'][$product_id]);
        }
        $response['success'] = true;
        $response['message'] = "Item removed from cart.";
    }
    elseif ($action === 'clear') {
        $_SESSION['cart'] = [];
        $response['success'] = true;
        $response['message'] = "Cart cleared.";
    }
    elseif ($action === 'get') {
        $response['success'] = true;
        $response['message'] = "Cart fetched.";
    }

    // Attach latest calculated totals
    $subtotal = get_cart_subtotal();
    $delivery_fee = get_delivery_fee($subtotal);
    $grand_total = $subtotal + $delivery_fee;

    $response['cart_count'] = get_cart_count();
    $response['subtotal'] = $subtotal;
    $response['formatted_subtotal'] = format_currency($subtotal);
    $response['delivery_fee'] = $delivery_fee;
    $response['formatted_delivery_fee'] = format_currency($delivery_fee);
    $response['grand_total'] = $grand_total;
    $response['formatted_grand_total'] = format_currency($grand_total);
    $response['items'] = get_cart_items();

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
    $response['cart_count'] = get_cart_count();
}

echo json_encode($response);
exit;
