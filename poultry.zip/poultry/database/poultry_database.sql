-- =======================================================
-- POULTRY MANAGEMENT SYSTEM - STANDALONE DATABASE DUMP
-- Database Name: poultry_db
-- Password Format: Plain Text (Unhashed) for Admin: 'admin123'
-- =======================================================

DROP DATABASE IF EXISTS `poultry_db`;
CREATE DATABASE `poultry_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `poultry_db`;

-- -------------------------------------------------------
-- 1. Table structure for table `users`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `full_name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL, -- Stored as plain text for admin ('admin123')
    `role` ENUM('customer', 'admin') NOT NULL DEFAULT 'customer',
    `phone` VARCHAR(30) NULL,
    `address` TEXT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Users (Admin with PLAIN TEXT password 'admin123', Customer 'customer123')
INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `role`, `phone`, `address`, `created_at`) VALUES
(1, 'Farm Administrator', 'admin@poultryfarm.com', 'admin123', 'admin', '+1 (555) 019-2834', '100 Green Acres Rd, Poultry Valley, CA', NOW()),
(2, 'Sarah Jenkins', 'customer@poultryfarm.com', 'customer123', 'customer', '+1 (555) 432-8765', '45 Meadow Lane, Farmville, CA', NOW());

-- -------------------------------------------------------
-- 2. Table structure for table `categories`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(120) NOT NULL UNIQUE,
    `description` TEXT NULL,
    `icon` VARCHAR(50) DEFAULT 'bi-egg',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Categories
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `icon`) VALUES
(1, 'Broiler Chickens', 'broilers', 'Healthy, fast-growing table meat chickens raised with organic feed.', 'bi-feather'),
(2, 'Layer Chickens', 'layers', 'High-producing point-of-lay hens and mature layers for premium egg output.', 'bi-egg'),
(3, 'Day-Old Chicks', 'day-old-chicks', 'Vigorously vaccinated day-old chicks: broilers, layers, and indigenous breeds.', 'bi-brightness-high'),
(4, 'Farm Fresh Eggs', 'fresh-eggs', 'Grade A organic brown, white, and fertilized hatching eggs.', 'bi-egg-fill'),
(5, 'Poultry Feeds', 'poultry-feeds', 'High-protein starter, grower, layer mash, and finisher feeds.', 'bi-box-seam'),
(6, 'Farm Equipment & Care', 'equipment-care', 'Drinkers, automated feeders, heating lamps, vitamins, and vaccines.', 'bi-tools');

-- -------------------------------------------------------
-- 3. Table structure for table `products`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `category_id` INT NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `slug` VARCHAR(180) NOT NULL UNIQUE,
    `price` DECIMAL(10, 2) NOT NULL,
    `unit` VARCHAR(50) NOT NULL DEFAULT 'unit',
    `stock_quantity` INT NOT NULL DEFAULT 0,
    `image_url` VARCHAR(255) NULL,
    `description` TEXT NULL,
    `featured` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Products
INSERT INTO `products` (`id`, `category_id`, `name`, `slug`, `price`, `unit`, `stock_quantity`, `image_url`, `description`, `featured`, `status`) VALUES
(1, 1, 'Mature Broiler Chicken (Whole Live)', 'mature-broiler-chicken', 14.50, 'per bird', 250, 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=600&q=80', 'Healthy, well-fed 6-week-old organic broiler birds averaging 2.2kg to 2.6kg. Plump and ready for processing.', 1, 'active'),
(2, 2, 'Point of Lay Hens (18 Weeks)', 'point-of-lay-hens', 18.00, 'per hen', 120, 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=600&q=80', 'Fully vaccinated Lohmann Brown / Isa Brown pullets on the verge of egg production. Expect 90%+ lay rate.', 1, 'active'),
(3, 3, 'Day-Old Broiler Chicks (Batch of 50)', 'day-old-broiler-chicks-50', 65.00, 'per box (50 chicks)', 40, 'https://images.unsplash.com/photo-1563281577-a7be47e20db9?auto=format&fit=crop&w=600&q=80', 'First-grade commercial broiler day-old chicks vaccinated against Marek\'s and Newcastle disease.', 1, 'active'),
(4, 4, 'Organic Brown Eggs (Crate of 30)', 'organic-brown-eggs-crate', 7.50, 'per crate (30 eggs)', 300, 'https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&w=600&q=80', 'Farm fresh, free-range organic brown table eggs harvested daily. Clean, unwashed, with rich golden yolks.', 1, 'active'),
(5, 5, 'High Protein Broiler Finisher (50kg)', 'broiler-finisher-50kg', 36.00, 'per 50kg bag', 85, 'https://images.unsplash.com/photo-1628102491629-778571d893a3?auto=format&fit=crop&w=600&q=80', 'Nutritionally balanced high-energy finisher pellets formulated for optimal weight gain during weeks 4 to 7.', 0, 'active'),
(6, 4, 'Fertilized Hatching Eggs (Crate of 30)', 'fertilized-hatching-eggs', 12.00, 'per crate (30 eggs)', 90, 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=600&q=80', 'Carefully selected fertile eggs with guaranteed 85%+ hatchability rate for your farm incubators.', 1, 'active'),
(7, 6, 'Automatic Bell Drinker (10L)', 'automatic-bell-drinker', 15.00, 'per unit', 150, 'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=600&q=80', 'Durable, heavy-duty suspension bell drinker providing continuous clean water supply for up to 80 birds.', 0, 'active'),
(8, 5, 'Layer Mash Feed (50kg)', 'layer-mash-feed-50kg', 34.50, 'per 50kg bag', 110, 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=600&q=80', 'Calcium-fortified premium feed ensuring sturdy eggshells, vibrant yolks, and consistent daily laying.', 0, 'active');

-- -------------------------------------------------------
-- 4. Table structure for table `orders`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_number` VARCHAR(50) NOT NULL UNIQUE,
    `user_id` INT NULL,
    `customer_name` VARCHAR(150) NOT NULL,
    `customer_email` VARCHAR(191) NOT NULL,
    `customer_phone` VARCHAR(30) NOT NULL,
    `delivery_address` TEXT NOT NULL,
    `payment_method` VARCHAR(50) NOT NULL DEFAULT 'Cash on Delivery',
    `payment_status` ENUM('Pending', 'Paid', 'Failed') NOT NULL DEFAULT 'Pending',
    `subtotal` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    `delivery_fee` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    `status` ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') NOT NULL DEFAULT 'Pending',
    `notes` TEXT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Sample Order
INSERT INTO `orders` (`id`, `order_number`, `user_id`, `customer_name`, `customer_email`, `customer_phone`, `delivery_address`, `payment_method`, `payment_status`, `subtotal`, `delivery_fee`, `total_amount`, `status`, `notes`, `created_at`) VALUES
(1, 'ORD-20260901-7821', 2, 'Sarah Jenkins', 'customer@poultryfarm.com', '+1 (555) 432-8765', '45 Meadow Lane, Farmville, CA', 'Cash on Delivery', 'Pending', 44.00, 5.00, 49.00, 'Processing', 'Please deliver in morning hours before 11 AM.', NOW());

-- -------------------------------------------------------
-- 5. Table structure for table `order_items`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `product_id` INT NULL,
    `product_name` VARCHAR(150) NOT NULL,
    `unit_price` DECIMAL(10, 2) NOT NULL,
    `unit` VARCHAR(50) NOT NULL DEFAULT 'unit',
    `quantity` INT NOT NULL,
    `subtotal` DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Order Items
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `unit_price`, `unit`, `quantity`, `subtotal`) VALUES
(1, 1, 1, 'Mature Broiler Chicken (Whole Live)', 14.50, 'per bird', 2, 29.00),
(2, 1, 4, 'Organic Brown Eggs (Crate of 30)', 7.50, 'per crate (30 eggs)', 2, 15.00);

-- -------------------------------------------------------
-- 6. Table structure for table `contact_messages`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE `contact_messages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `phone` VARCHAR(30) NULL,
    `subject` VARCHAR(200) NOT NULL,
    `message` TEXT NOT NULL,
    `status` ENUM('Unread', 'Read', 'Replied') NOT NULL DEFAULT 'Unread',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- 7. Table structure for table `settings`
-- -------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
    `setting_key` VARCHAR(100) PRIMARY KEY,
    `setting_value` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Settings
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('farm_name', 'FeatherFarm Poultry Management'),
('farm_tagline', 'Fresh, Healthy & Organically Raised Poultry Direct From Our Hatchery'),
('phone', '+1 (555) 789-2345'),
('email', 'info@poultryfarm.com'),
('address', 'Plot 42 Green Valley Road, Sunrise Agricultural Hub, CA 90210'),
('currency', '$'),
('delivery_fee', '5.00'),
('free_delivery_threshold', '100.00'),
('working_hours', 'Mon - Sat: 7:00 AM - 6:00 PM, Sunday: 8:00 AM - 2:00 PM');
