<?php
/**
 * Checkout & Order Submission Page
 * FeatherFarm Poultry Management System
 */
ob_start();
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Checkout';
$cart_items = get_cart_items();
// If cart is empty, redirect to shop
if (empty($cart_items)) {
    set_flash_message('warning', 'Your shopping cart is empty. Please add items before checking out.');
    header('Location: /poultry/shop.php');
    exit;
}
$subtotal = get_cart_subtotal();
$delivery_fee = get_delivery_fee($subtotal);
$grand_total = $subtotal + $delivery_fee;
$user = current_user();
$customer_name = $user['full_name'] ?? '';
$customer_email = $user['email'] ?? '';
$customer_phone = $user['phone'] ?? '';
$delivery_address = $user['address'] ?? '';
$payment_method = 'Cash on Delivery';
$notes = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = clean_input($_POST['customer_name'] ?? '');
    $customer_email = clean_input($_POST['customer_email'] ?? '');
    $customer_phone = clean_input($_POST['customer_phone'] ?? '');
    $delivery_address = clean_input($_POST['delivery_address'] ?? '');
    $payment_method = clean_input($_POST['payment_method'] ?? 'Cash on Delivery');
    $notes = clean_input($_POST['notes'] ?? '');
    if (empty($customer_name) || empty($customer_email) || empty($customer_phone) || empty($delivery_address)) {
        $error = 'Please fill in all required delivery contact and address details.';
    } elseif (!filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            $pdo = get_db();
            $pdo->beginTransaction();
            // Re-verify stock for each item before placing order
            foreach ($cart_items as $item) {
                $stmt = $pdo->prepare("SELECT `stock_quantity`, `name` FROM `products` WHERE `id` = ? FOR UPDATE");
                $stmt->execute([$item['product_id']]);
                $current_stock = $stmt->fetch();
                if (!$current_stock || (int)$current_stock['stock_quantity'] < $item['quantity']) {
                    throw new Exception("Insufficient stock for <strong>" . htmlspecialchars($item['name']) . "</strong>. Available: " . ($current_stock['stock_quantity'] ?? 0));
                }
            }
            // Generate unique Order Number
            $order_number = generate_order_number();
            $user_id = $user['id'] ?? null;
            // Insert into orders table
            $stmt = $pdo->prepare("
                INSERT INTO `orders` 
                (`order_number`, `user_id`, `customer_name`, `customer_email`, `customer_phone`, `delivery_address`, `payment_method`, `payment_status`, `subtotal`, `delivery_fee`, `total_amount`, `status`, `notes`) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, 'Pending', ?)
            ");
            $stmt->execute([
                $order_number,
                $user_id,
                $customer_name,
                $customer_email,
                $customer_phone,
                $delivery_address,
                $payment_method,
                $subtotal,
                $delivery_fee,
                $grand_total,
                $notes
            ]);
            $order_id = $pdo->lastInsertId();
            // Insert order items and deduct inventory
            $stmt_item = $pdo->prepare("
                INSERT INTO `order_items` 
                (`order_id`, `product_id`, `product_name`, `unit_price`, `unit`, `quantity`, `subtotal`) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt_stock = $pdo->prepare("
                UPDATE `products` 
                SET `stock_quantity` = `stock_quantity` - ? 
                WHERE `id` = ?
            ");
            foreach ($cart_items as $item) {
                $stmt_item->execute([
                    $order_id,
                    $item['product_id'],
                    $item['name'],
                    $item['price'],
                    $item['unit'],
                    $item['quantity'],
                    $item['subtotal']
                ]);
                $stmt_stock->execute([
                    $item['quantity'],
                    $item['product_id']
                ]);
            }
            $pdo->commit();
            // Clear the cart
            $_SESSION['cart'] = [];
            $_SESSION['last_order'] = [
                'id' => $order_id,
                'order_number' => $order_number
            ];
            // Redirect cleanly to confirmation page
            header("Location: /poultry/order-success.php?order=" . urlencode($order_number));
            exit;
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "Order processing failed: " . $e->getMessage();
        }
    }
}
// Require HTML header only after all redirects and POST processing
require_once __DIR__ . '/includes/header.php';
?>
<div class="container py-4">
    <div class="mb-4">
        <h1 class="h2 fw-bold text-success mb-1">Checkout & Place Order</h1>
        <p class="text-muted small mb-0">Complete your delivery address and choose your preferred payment option.</p>
    </div>
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
            <i class="bi bi-exclamation-triangle-fill fs-5 me-2"></i>
            <div><?= $error ?></div>
        </div>
    <?php endif; ?>
    <form method="POST" action="checkout.php" class="needs-validation">
        <div class="row g-4">
            <!-- LEFT COLUMN: CUSTOMER & DELIVERY DETAILS -->
            <div class="col-lg-7">
                <!-- Contact Information -->
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3 text-dark d-flex align-items-center">
                        <span class="badge bg-success rounded-circle me-2 p-2">1</span>
                        Customer & Contact Information
                    </h5>
                    <?php if (!is_logged_in()): ?>
                        <div class="alert alert-light border d-flex justify-content-between align-items-center mb-3 py-2">
                            <span class="small text-muted">Already registered with FeatherFarm?</span>
                            <a href="/poultry/auth/login.php" class="btn btn-sm btn-outline-success">Sign In First</a>
                        </div>
                    <?php endif; ?>
                    <div class="row g-3">
                        <div class="col-12">
                            <label for="customer_name" class="form-label fw-semibold small">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?= htmlspecialchars($customer_name) ?>" placeholder="e.g. Sarah Jenkins" required>
                        </div>
                        <div class="col-md-6">
                            <label for="customer_email" class="form-label fw-semibold small">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="customer_email" name="customer_email" value="<?= htmlspecialchars($customer_email) ?>" placeholder="name@example.com" required>
                        </div>
                        <div class="col-md-6">
                            <label for="customer_phone" class="form-label fw-semibold small">Phone Number <span class="text-danger">*</span></label>
                            <input type="tel" class="form-control" id="customer_phone" name="customer_phone" value="<?= htmlspecialchars($customer_phone) ?>" placeholder="+1 (555) 432-8765" required>
                        </div>
                    </div>
                </div>
                <!-- Delivery Address -->
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3 text-dark d-flex align-items-center">
                        <span class="badge bg-success rounded-circle me-2 p-2">2</span>
                        Farm / Home Delivery Address
                    </h5>
                    <div class="mb-3">
                        <label for="delivery_address" class="form-label fw-semibold small">Delivery Address & Landmark <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="delivery_address" name="delivery_address" rows="3" placeholder="Enter street, farm gate / house number, neighborhood, or specific directions" required><?= htmlspecialchars($delivery_address) ?></textarea>
                    </div>
                    <div class="mb-0">
                        <label for="notes" class="form-label fw-semibold small">Special Delivery Instructions / Flock Notes (Optional)</label>
                        <input type="text" class="form-control" id="notes" name="notes" value="<?= htmlspecialchars($notes) ?>" placeholder="e.g. Call upon arrival at gate, morning delivery preferred">
                    </div>
                </div>
                <!-- Payment Method -->
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3 text-dark d-flex align-items-center">
                        <span class="badge bg-success rounded-circle me-2 p-2">3</span>
                        Payment Method
                    </h5>
                    <div class="d-flex flex-column gap-3">
                        <label class="form-check p-3 border rounded-3 d-flex align-items-center cursor-pointer">
                            <input class="form-check-input me-3" type="radio" name="payment_method" value="Cash on Delivery" checked>
                            <div>
                                <strong class="d-block"><i class="bi bi-cash-stack text-success me-1"></i> Cash on Delivery / Pay on Delivery</strong>
                                <small class="text-muted">Inspect your live birds or eggs upon arrival and pay cash or mobile transfer to the driver.</small>
                            </div>
                        </label>
                        <label class="form-check p-3 border rounded-3 d-flex align-items-center cursor-pointer">
                            <input class="form-check-input me-3" type="radio" name="payment_method" value="Direct Bank Transfer">
                            <div>
                                <strong class="d-block"><i class="bi bi-bank text-primary me-1"></i> Direct Bank Transfer</strong>
                                <small class="text-muted">Transfer to our farm corporate account. Order is confirmed once payment receipt is verified.</small>
                            </div>
                        </label>
                        <label class="form-check p-3 border rounded-3 d-flex align-items-center cursor-pointer">
                            <input class="form-check-input me-3" type="radio" name="payment_method" value="Mobile Money / Card">
                            <div>
                                <strong class="d-block"><i class="bi bi-phone text-warning me-1"></i> Mobile Money / Online Card</strong>
                                <small class="text-muted">Instant mobile payment or debit card processing.</small>
                            </div>
                        </label>
                    </div>
                </div>
            </div>
            <!-- RIGHT COLUMN: ORDER SUMMARY & SUBMIT BUTTON -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm rounded-4 p-4 sticky-top" style="top: 90px;">
                    <h5 class="fw-bold mb-3 border-bottom pb-2">Items in Order (<?= count($cart_items) ?>)</h5>
                    <div class="cart-items-preview mb-3" style="max-height: 280px; overflow-y: auto;">
                        <?php foreach ($cart_items as $item): ?>
                            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                <div class="d-flex align-items-center">
                                    <img src="<?= htmlspecialchars($item['image_url'] ?? 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=150&q=80') ?>" class="rounded-2 me-2" style="width: 44px; height: 44px; object-fit: cover;">
                                    <div>
                                        <h6 class="mb-0 small fw-bold text-dark text-truncate" style="max-width: 180px;"><?= htmlspecialchars($item['name']) ?></h6>
                                        <small class="text-muted"><?= $item['quantity'] ?> &times; <?= format_currency($item['price']) ?></small>
                                    </div>
                                </div>
                                <span class="fw-bold text-success small"><?= format_currency($item['subtotal']) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="d-flex justify-content-between mb-2 small">
                        <span class="text-secondary">Subtotal</span>
                        <span class="fw-bold"><?= format_currency($subtotal) ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-3 small">
                        <span class="text-secondary">Delivery Fee</span>
                        <span class="fw-bold text-success">
                            <?= $delivery_fee == 0 ? '<span class="badge bg-success">FREE</span>' : format_currency($delivery_fee) ?>
                        </span>
                    </div>
                    <hr class="my-2">
                    <div class="d-flex justify-content-between align-items-baseline mb-4">
                        <span class="fs-5 fw-bold">Grand Total</span>
                        <span class="fs-4 fw-extrabold text-success"><?= format_currency($grand_total) ?></span>
                    </div>
                    <!-- SUBMIT ORDER BUTTON -->
                    <div class="d-grid mb-3">
                        <button type="submit" class="btn btn-farm-primary btn-lg py-3 fw-bold rounded-pill shadow">
                            <i class="bi bi-check2-circle me-2"></i> Submit & Confirm Order
                        </button>
                    </div>
                    <div class="text-center text-muted small">
                        <i class="bi bi-lock-fill text-success me-1"></i> By clicking Submit, your order will be placed into processing.
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
