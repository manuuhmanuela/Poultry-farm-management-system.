<?php
/**
 * Order Success Confirmation Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'Order Confirmed';
require_once __DIR__ . '/includes/header.php';

$order_number = clean_input($_GET['order'] ?? '');
$order = null;
$order_items = [];

if (!empty($order_number)) {
    try {
        $pdo = get_db();
        $stmt = $pdo->prepare("SELECT * FROM `orders` WHERE `order_number` = ? LIMIT 1");
        $stmt->execute([$order_number]);
        $order = $stmt->fetch();

        if ($order) {
            $stmt_items = $pdo->prepare("SELECT * FROM `order_items` WHERE `order_id` = ?");
            $stmt_items->execute([$order['id']]);
            $order_items = $stmt_items->fetchAll();
        }
    } catch (Exception $e) {}
}
?>

<div class="container py-5 my-md-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-success text-white text-center py-5">
                    <div class="brand-icon-box bg-white text-success mx-auto mb-3" style="width: 70px; height: 70px; font-size: 2.2rem;">
                        <i class="bi bi-check-lg"></i>
                    </div>
                    <h2 class="fw-bold mb-1">Order Received Successfully!</h2>
                    <p class="text-white-50 mb-0">Thank you for ordering with FeatherFarm. Your flock order is in processing.</p>
                </div>

                <div class="card-body p-4 p-md-5">
                    <?php if ($order): ?>
                        <div class="alert alert-light border rounded-3 p-3 mb-4 d-flex flex-wrap justify-content-between align-items-center">
                            <div>
                                <span class="text-muted small d-block">Order Reference Number:</span>
                                <h4 class="fw-bold text-success mb-0"><code><?= htmlspecialchars($order['order_number']) ?></code></h4>
                            </div>
                            <div class="text-md-end mt-2 mt-md-0">
                                <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fs-6">
                                    Status: <?= htmlspecialchars($order['status']) ?>
                                </span>
                            </div>
                        </div>

                        <!-- Order Details Overview -->
                        <div class="row g-4 mb-4">
                            <div class="col-md-6">
                                <h6 class="fw-bold text-secondary text-uppercase small mb-2">Delivery Details</h6>
                                <p class="mb-1 fw-bold"><?= htmlspecialchars($order['customer_name']) ?></p>
                                <p class="mb-1 small text-muted"><i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($order['customer_phone']) ?></p>
                                <p class="mb-1 small text-muted"><i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($order['customer_email']) ?></p>
                                <p class="mb-0 small text-muted"><i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($order['delivery_address']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6 class="fw-bold text-secondary text-uppercase small mb-2">Payment & Delivery Summary</h6>
                                <p class="mb-1 small"><strong>Payment Method:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
                                <p class="mb-1 small"><strong>Order Placed:</strong> <?= date('F j, Y - g:i A', strtotime($order['created_at'])) ?></p>
                                <p class="mb-1 small"><strong>Subtotal:</strong> <?= format_currency($order['subtotal']) ?></p>
                                <p class="mb-1 small"><strong>Delivery Fee:</strong> <?= $order['delivery_fee'] == 0 ? 'FREE' : format_currency($order['delivery_fee']) ?></p>
                                <p class="mb-0 fw-bold fs-5 text-success"><strong>Total Amount:</strong> <?= format_currency($order['total_amount']) ?></p>
                            </div>
                        </div>

                        <!-- Ordered Items List -->
                        <div class="card border rounded-3 mb-4 overflow-hidden">
                            <div class="card-header bg-light fw-bold py-2 small">
                                <i class="bi bi-basket2 me-1"></i> Poultry & Farm Supplies in This Order
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm align-middle mb-0">
                                    <thead class="table-light small">
                                        <tr>
                                            <th class="ps-3">Item</th>
                                            <th class="text-center">Price</th>
                                            <th class="text-center">Quantity</th>
                                            <th class="pe-3 text-end">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($order_items as $item): ?>
                                            <tr>
                                                <td class="ps-3 py-2 fw-semibold">
                                                    <?= htmlspecialchars($item['product_name']) ?>
                                                    <small class="text-muted d-block"><?= htmlspecialchars($item['unit']) ?></small>
                                                </td>
                                                <td class="text-center"><?= format_currency($item['unit_price']) ?></td>
                                                <td class="text-center"><?= $item['quantity'] ?></td>
                                                <td class="pe-3 text-end fw-bold"><?= format_currency($item['subtotal']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="d-flex flex-wrap gap-3 justify-content-between align-items-center">
                            <a href="/poultry/customer/my-orders.php?order=<?= urlencode($order['order_number']) ?>" class="btn btn-farm-primary px-4 py-2 rounded-pill">
                                <i class="bi bi-truck me-2"></i> Track Live Order Status
                            </a>
                            <a href="/poultry/shop.php" class="btn btn-outline-secondary px-4 py-2 rounded-pill">
                                <i class="bi bi-cart3 me-1"></i> Continue Shopping
                            </a>
                        </div>

                    <?php else: ?>
                        <div class="text-center py-4">
                            <p class="text-muted mb-3">Your order has been recorded. Check your orders page to monitor delivery progress.</p>
                            <a href="/poultry/customer/my-orders.php" class="btn btn-farm-primary px-4 py-2 rounded-pill">
                                View My Orders
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
