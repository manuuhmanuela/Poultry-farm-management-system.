# FeatherFarm - Poultry Management & E-Commerce Web System

A complete, responsive, full-stack **Poultry Management System** developed with **PHP**, **MySQL**, **JavaScript (ES6)**, **HTML5**, **Bootstrap 5.3**, and custom **CSS3**.

---

## 🌟 Features Overview

### 1. Customer & Public Portal
- **User Authentication**:
  - Customer Registration (`/poultry/auth/register.php`) with password hashing (`PASSWORD_BCRYPT`).
  - Secure Login (`/poultry/auth/login.php`) with 1-click Demo Account Autofill.
  - Role-based redirection and session management.
- **Home Page (`/poultry/index.php`)**:
  - Modern hero banner with quick CTA buttons and statistics counter.
  - Farm highlights: Biosecurity, 100% Organic, Direct Farm Delivery, Expert Vet Support.
  - Featured poultry & products dynamically queried from MySQL.
  - Core services preview and customer testimonials.
- **Our Services (`/poultry/services.php`)**:
  - Detailed showcases for:
    - Day-Old Chicks Supply (broilers, layers, and indigenous breeds)
    - Broiler & Layer Rearing (table broilers & point-of-lay hens)
    - Nutrition & Feed Milling (starter, grower, layer, and finisher feeds)
    - Veterinary Care & Vaccination Scheduling
    - Battery Cages & Automated Poultry Equipment
    - Bulk Wholesale & Commercial Supply
- **Buy Poultry / Shop (`/poultry/shop.php`)**:
  - Category filter pills (Broilers, Layers, Chicks, Eggs, Feeds, Equipment).
  - Search bar and price/name sorting.
  - Live stock indicators (`In Stock`, `Low Stock`, `Out of Stock`).
  - Unit pricing (e.g. *per bird*, *per crate of 30*, *per 50kg bag*).
  - Quantity selector and interactive "Add to Cart" button.
- **Shopping Cart (`/poultry/cart.php`)**:
  - AJAX real-time item counter in navbar.
  - Quantity modifiers (+ / -), automatic line subtotal recalculation, and item removal.
  - Free delivery threshold calculator and incentives.
- **Checkout & Order Submission (`/poultry/checkout.php`)**:
  - Pre-fills customer contact info for logged-in accounts.
  - Farm / home delivery address input and special notes.
  - Payment methods: Cash on Delivery, Direct Bank Transfer, Mobile Money / Card.
  - Transactional order creation with unique Order Number (`ORD-YYYYMMDD-XXXXX`).
  - Automatic inventory deduction upon order placement.
- **Order Status Tracking (`/poultry/customer/my-orders.php`)**:
  - Real-time **4-Step Visual Progress Bar**:
    `[1. Order Placed] ──> [2. Processing & Packing] ──> [3. Out for Delivery] ──> [4. Delivered]`
  - Order history table with receipts and item breakdowns.
  - Direct order search bar for quick lookup.
- **Contact Us (`/poultry/contact.php`)**:
  - Interactive inquiry and quote request form with database logging.
  - Farm headquarters address, phone hotline, email, and business hours.

---

### 2. Administrator Portal (`/poultry/admin/`)
- **Admin Dashboard (`/poultry/admin/index.php`)**:
  - Real-time KPI Cards: Total Sales Revenue, Total Customer Orders, Registered Customers, Active Products, and Low Stock Alerts.
  - Recent Orders table with instant status badges.
  - Stock Watchlist highlighting products running low.
- **Add Menu / Product Management (`/poultry/admin/products.php`)**:
  - Complete poultry inventory table with category filter and search.
  - **"Add Product / Menu Item"** modal: Product Name, Category, Price, Unit, Stock Quantity, Image URL, Description, and Featured toggle.
  - **"Edit Product"** modal: Adjust pricing, stock levels, or details anytime.
  - **"Delete Product"** action with confirmation safety check.
- **Update Order Status (`/poultry/admin/orders.php`)**:
  - Filter orders by status (All, Pending, Processing, Shipped, Delivered, Cancelled).
  - Search by Order #, Customer Name, or Phone number.
  - Real-time **Order Status Updater** modal (updates status instantly in database and propagates to the customer's live tracking view!).
  - View full itemized order items and customer shipping address.
- **Registered Customers Directory (`/poultry/admin/customers.php`)**:
  - Full table of registered customers: Name, Email, Phone, Address, Date Registered.
  - Aggregated metrics per customer: Total Orders Placed and Lifetime Money Spent.
  - Direct link to view all orders placed by each specific customer.
- **Customer Inquiries & Messages (`/poultry/admin/messages.php`)**:
  - View contact form submissions and quote requests with read/replied status.
- **Farm & Store Settings (`/poultry/admin/settings.php`)**:
  - Farm Name, Tagline, Phone, Email, Address, and Business Hours.
  - E-Commerce settings: Currency Symbol (e.g. `$`, `KSh`, `₦`, `€`, `£`), Flat Delivery Fee, and Free Delivery Threshold.
  - Administrator Password update form.

---

## 🚀 Quick Setup Instructions

### Option A: Using XAMPP / WAMP / Laragon (Recommended)

1. **Place the Folder**:
   Copy or move this `poultry` folder into your web server's root directory:
   - For **XAMPP**: `C:\xampp\htdocs\poultry`
   - For **WAMP**: `C:\wamp64\www\poultry`
   - For **Laragon**: `C:\laragon\www\poultry`

2. **Start Services**:
   Start **Apache** and **MySQL** from your XAMPP/WAMP control panel.

3. **Run 1-Click Database Installer**:
   Open your browser and navigate to:
   ```
   http://localhost/poultry/setup.php
   ```
   Click **"Install Database & Seed Data Now"**.
   This will automatically:
   - Create the `poultry_db` database in MySQL.
   - Execute `database/schema.sql` to build all tables and relationships.
   - Seed sample poultry breeds, egg batches, feeds, categories, demo accounts, and store settings.

4. **Launch the System**:
   - Customer Store & Home: `http://localhost/poultry/index.php`
   - Buy Poultry: `http://localhost/poultry/shop.php`
   - Admin Dashboard: `http://localhost/poultry/admin/index.php`

---

### Option B: Using PHP Built-in Server

If you have PHP and MySQL installed directly:
1. Open PowerShell or Command Prompt in `c:\Users\Manu\Downloads\poultry`.
2. Start the built-in server:
   ```bash
   php -S localhost:8000
   ```
3. Open `http://localhost:8000/setup.php` in your browser to complete database setup.

---

## 🔑 Default Login Credentials

| Role | Email Address | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@poultryfarm.com` | `admin123` | Full Admin Dashboard, Manage Products, Update Status, Customers, Settings |
| **Customer Demo** | `customer@poultryfarm.com` | `customer123` | Shop, Add to Cart, Checkout, Live Order Tracking, Order History |

*(Note: You can also use the **Quick Demo Fill** buttons on the login page for 1-click access)*

---

## 📁 File & Directory Architecture

```
poultry/
├── admin/                     # Administrator Portal
│   ├── includes/
│   │   ├── admin-header.php   # Admin responsive sidebar, top bar & auth check
│   │   └── admin-footer.php   # Admin scripts & closing tags
│   ├── index.php              # Admin Dashboard KPIs & recent sales
│   ├── products.php           # Add Menu / Product inventory CRUD
│   ├── orders.php             # Order management & live status updater
│   ├── customers.php          # Registered customers directory & lifetime spend
│   ├── messages.php           # Contact inquiries & quotes
│   └── settings.php           # Farm info, currency, shipping fees & admin password
├── api/
│   └── cart-actions.php       # AJAX Shopping Cart API (add, update, remove, totals)
├── assets/
│   ├── css/
│   │   └── style.css          # Custom styling, order progress timeline, cards
│   └── js/
│       └── main.js            # Dynamic cart controller, toast alerts, spinners
├── auth/
│   ├── login.php              # Customer & Admin login with demo fill buttons
│   ├── register.php           # Customer registration & password hashing
│   └── logout.php             # Session termination & redirect
├── config/
│   └── db.php                 # PDO MySQL singleton connection
├── customer/
│   └── my-orders.php          # Live 4-step order tracking timeline & order history
├── database/
│   └── schema.sql             # MySQL schema & pre-seeded poultry data
├── includes/
│   ├── functions.php          # Helper functions, sessions, settings & cart logic
│   ├── header.php             # Responsive Bootstrap 5 navbar & user profile menu
│   └── footer.php             # Responsive 4-column footer & contact info
├── cart.php                   # Shopping cart page with line totals & fee threshold
├── checkout.php               # Checkout page with delivery address & order submission
├── contact.php                # Contact Us page with message form
├── index.php                  # Home page (Hero, stats, featured products, services)
├── order-success.php          # Order confirmation receipt & direct tracking link
├── services.php               # Our Services page (chicks, broilers, feeds, vet care)
├── setup.php                  # 1-Click web installer & database migrator
├── shop.php                   # Buy poultry products catalog with filters & search
└── README.md                  # Project documentation & setup instructions
```

---

## 🛡️ Security Best Practices
- **Prepared Statements (PDO)**: All SQL queries use parameterized prepared statements preventing SQL Injection.
- **BCRYPT Password Hashing**: Passwords stored using PHP `password_hash()` and verified via `password_verify()`.
- **Role-Based Authorization**: `require_admin()` safeguards all `/admin/` routes against unauthorized customer or guest access.
- **Input Sanitization**: User inputs cleaned using `htmlspecialchars()` preventing Cross-Site Scripting (XSS).
- **Database Transactions**: Checkout operations execute within PDO transactions ensuring atomicity when creating orders, inserting items, and deducting inventory.
