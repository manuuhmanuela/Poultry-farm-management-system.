<?php
/**
 * Shopping Cart Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'Shopping Cart';
require_once __DIR__ . '/includes/header.php';

$cart_items = get_cart_items();
$subtotal = get_cart_subtotal();
$delivery_fee = get_delivery_fee($subtotal);
$grand_total = $subtotal + $delivery_fee;
$free_threshold = (float)get_setting('free_delivery_threshold', '100.00');
?>

<div class="container py-4">
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h2 fw-bold text-success mb-1">Your Shopping Cart</h1>
            <p class="text-muted small mb-0">Review your selected poultry birds, eggs, and feeds before checkout.</p>
        </div>
        <a href="/poultry/shop.php" class="btn btn-outline-success btn-sm rounded-pill fw-semibold">
            <i class="bi bi-arrow-left me-1"></i> Continue Shopping
        </a>
    </div>

    <?php if (!empty($cart_items)): ?>
        <div class="row g-4">
            <!-- CART ITEMS TABLE -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light text-secondary small text-uppercase">
                                <tr>
                                    <th class="ps-4 py-3" style="min-width: 250px;">Product</th>
                                    <th class="py-3 text-center">Unit Price</th>
                                    <th class="py-3 text-center" style="min-width: 130px;">Quantity</th>
                                    <th class="py-3 text-end">Subtotal</th>
                                    <th class="pe-4 py-3 text-center" style="width: 50px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_items as $item): ?>
                                    <tr id="cart-row-<?= $item['product_id'] ?>">
                                        <td class="ps-4 py-3">
                                            <div class="d-flex align-items-center">
                                                <img src="<?= htmlspecialchars($item['image_url'] ?? 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=150&q=80') ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="rounded-3 me-3" style="width: 60px; height: 60px; object-fit: cover;">
                                                <div>
                                                    <h6 class="fw-bold mb-0 text-dark"><?= htmlspecialchars($item['name']) ?></h6>
                                                    <small class="text-muted d-block"><?= htmlspecialchars($item['category'] ?? 'Poultry') ?> &bull; <?= htmlspecialchars($item['unit']) ?></small>
                                                    <small class="text-success fw-semibold"><i class="bi bi-check-circle"></i> In Stock (<?= $item['stock'] ?> available)</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center fw-semibold">
                                            <?= format_currency($item['price']) ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="input-group input-group-sm justify-content-center" style="max-width: 120px; margin: 0 auto;">
                                                <button class="btn btn-outline-secondary btn-cart-qty-minus" type="button" data-product-id="<?= $item['product_id'] ?>">-</button>
                                                <input type="number" class="form-control text-center cart-qty-input" data-product-id="<?= $item['product_id'] ?>" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>">
                                                <button class="btn btn-outline-secondary btn-cart-qty-plus" type="button" data-product-id="<?= $item['product_id'] ?>">+</button>
                                            </div>
                                        </td>
                                        <td class="text-end fw-bold text-success" id="line-subtotal-<?= $item['product_id'] ?>">
                                            <?= format_currency($item['subtotal']) ?>
                                        </td>
                                        <td class="pe-4 text-center">
                                            <button class="btn btn-sm btn-outline-danger border-0 rounded-circle btn-cart-remove" data-product-id="<?= $item['product_id'] ?>" title="Remove item">
                                                <i class="bi bi-trash3-fill"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Free delivery incentive notice -->
                <?php if ($subtotal < $free_threshold): ?>
                    <div class="alert alert-info border-0 shadow-sm rounded-4 d-flex align-items-center mb-0">
                        <i class="bi bi-truck fs-3 text-primary me-3"></i>
                        <div class="small">
                            Add <strong><?= format_currency($free_threshold - $subtotal) ?></strong> more of poultry or feeds to unlock <strong>FREE Farm Delivery</strong>!
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success border-0 shadow-sm rounded-4 d-flex align-items-center mb-0">
                        <i class="bi bi-gift-fill fs-3 text-success me-3"></i>
                        <div class="small">
                            Congratulations! Your order qualifies for <strong>FREE Farm Delivery</strong>!
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ORDER SUMMARY CARD -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 p-4 sticky-top" style="top: 90px;">
                    <h5 class="fw-bold mb-3 border-bottom pb-2">Order Summary</h5>

                    <div class="d-flex justify-content-between mb-2 small">
                        <span class="text-secondary">Subtotal</span>
                        <span class="fw-bold" id="cart-subtotal"><?= format_currency($subtotal) ?></span>
                    </div>

                    <div class="d-flex justify-content-between mb-3 small">
                        <span class="text-secondary">Delivery Fee</span>
                        <span class="fw-bold text-success" id="cart-delivery-fee">
                            <?= $delivery_fee == 0 ? '<span class="badge bg-success">FREE</span>' : format_currency($delivery_fee) ?>
                        </span>
                    </div>

                    <hr class="my-2">

                    <div class="d-flex justify-content-between align-items-baseline mb-4">
                        <span class="fs-5 fw-bold">Total Amount</span>
                        <span class="fs-4 fw-extrabold text-success" id="cart-grand-total"><?= format_currency($grand_total) ?></span>
                    </div>

                    <div class="d-grid gap-2">
                        <a href="/poultry/checkout.php" class="btn btn-farm-primary btn-lg py-3 fw-bold rounded-pill shadow-sm">
                            <i class="bi bi-credit-card-2-front me-2"></i> Proceed to Checkout
                        </a>
                        <a href="/poultry/shop.php" class="btn btn-outline-secondary py-2 rounded-pill small">
                            <i class="bi bi-plus-circle me-1"></i> Add More Poultry Items
                        </a>
                    </div>

                    <div class="mt-4 pt-3 border-top text-center text-muted small">
                        <div class="d-flex justify-content-center gap-3">
                            <span><i class="bi bi-shield-check text-success"></i> Secure Checkout</span>
                            <span><i class="bi bi-clock-history text-success"></i> Fresh Delivery</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <!-- EMPTY CART STATE -->
        <div class="card border-0 shadow-sm rounded-4 text-center py-5">
            <div class="card-body py-5">
                <div class="brand-icon-box bg-light text-muted mx-auto mb-3" style="width: 80px; height: 80px; font-size: 2.5rem;">
                    <i class="bi bi-cart-x"></i>
                </div>
                <h3 class="fw-bold mb-2">Your Cart is Currently Empty</h3>
                <p class="text-muted max-w-500 mx-auto mb-4">
                    Looks like you haven't added any poultry birds, eggs, or supplies to your shopping cart yet.
                </p>
                <a href="/poultry/shop.php" class="btn btn-farm-primary btn-lg px-5 py-3 rounded-pill fw-bold shadow-sm">
                    <i class="bi bi-bag-plus me-2"></i> Start Shopping Now
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
