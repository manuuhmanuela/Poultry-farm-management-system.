<?php
/**
 * Customer Order Status & History Tracking Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'My Orders & Status Tracking';
require_once __DIR__ . '/../includes/header.php';

$pdo = get_db();
$user = current_user();

// Allow searching by order number directly (guest tracking or quick lookup)
$search_order = clean_input($_GET['order'] ?? '');
$orders = [];
$active_order = null;
$active_items = [];

try {
    if (is_logged_in()) {
        // Fetch all orders for this user
        $stmt = $pdo->prepare("SELECT * FROM `orders` WHERE `user_id` = ? OR `customer_email` = ? ORDER BY `id` DESC");
        $stmt->execute([$user['id'], $user['email']]);
        $orders = $stmt->fetchAll();
    } elseif (!empty($search_order)) {
        // If guest looking up specific order
        $stmt = $pdo->prepare("SELECT * FROM `orders` WHERE `order_number` = ? LIMIT 1");
        $stmt->execute([$search_order]);
        $orders = $stmt->fetchAll();
    }

    // Determine which order to highlight in the status timeline
    if (!empty($search_order)) {
        foreach ($orders as $ord) {
            if ($ord['order_number'] === $search_order) {
                $active_order = $ord;
                break;
            }
        }
    }

    // Default to the most recent order if not specified
    if (!$active_order && !empty($orders)) {
        $active_order = $orders[0];
    }

    // Fetch items for the active order
    if ($active_order) {
        $stmt_items = $pdo->prepare("SELECT * FROM `order_items` WHERE `order_id` = ?");
        $stmt_items->execute([$active_order['id']]);
        $active_items = $stmt_items->fetchAll();
    }
} catch (Exception $e) {}

// Calculate tracking timeline progress percentages
$status_steps = ['Pending' => 1, 'Processing' => 2, 'Shipped' => 3, 'Delivered' => 4];
$current_status = $active_order['status'] ?? 'Pending';
$current_step = $status_steps[$current_status] ?? 1;
$progress_width = (($current_step - 1) / 3) * 100;
?>

<div class="container py-4">
    <!-- PAGE TITLE -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h2 fw-bold text-success mb-1">Track Poultry Orders</h1>
            <p class="text-muted small mb-0">Monitor live dispatch and delivery stages of your poultry batches and supplies.</p>
        </div>
        <div class="mt-3 mt-md-0">
            <!-- Quick Order Lookup Form -->
            <form method="GET" action="my-orders.php" class="d-flex gap-2">
                <input type="text" name="order" class="form-control form-control-sm" placeholder="Search Order # (e.g. ORD-...)" value="<?= htmlspecialchars($search_order) ?>" style="min-width: 220px;" required>
                <button type="submit" class="btn btn-sm btn-farm-primary px-3">
                    <i class="bi bi-search"></i> Track
                </button>
            </form>
        </div>
    </div>

    <?php if ($active_order): ?>
        <!-- ACTIVE ORDER VISUAL STATUS TRACKER CARD -->
        <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5 mb-5 bg-white">
            <div class="d-flex flex-wrap justify-content-between align-items-center border-bottom pb-3 mb-4">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Live Tracking Order:</span>
                    <h3 class="fw-extrabold text-success mb-0"><?= htmlspecialchars($active_order['order_number']) ?></h3>
                </div>
                <div class="text-md-end mt-2 mt-md-0">
                    <span class="text-muted small d-block">Placed on: <?= date('M d, Y - h:i A', strtotime($active_order['created_at'])) ?></span>
                    <?php if ($active_order['status'] === 'Cancelled'): ?>
                        <span class="badge bg-danger fs-6 px-3 py-2 mt-1">Order Cancelled</span>
                    <?php else: ?>
                        <span class="badge bg-warning text-dark fs-6 px-3 py-2 mt-1">Current State: <?= htmlspecialchars($active_order['status']) ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($active_order['status'] !== 'Cancelled'): ?>
                <!-- 4-STEP VISUAL PROGRESS TIMELINE -->
                <div class="order-tracking-timeline">
                    <div class="tracking-progress-bar" style="width: <?= $progress_width ?>%;"></div>

                    <!-- Step 1: Order Placed -->
                    <div class="tracking-step <?= $current_step >= 1 ? ($current_step == 1 ? 'current' : 'completed') : '' ?>">
                        <div class="step-icon-bubble">
                            <i class="bi bi-receipt"></i>
                        </div>
                        <span class="step-title">Order Placed</span>
                        <small class="text-muted d-none d-md-block">Received at farm</small>
                    </div>

                    <!-- Step 2: Processing / Packing -->
                    <div class="tracking-step <?= $current_step >= 2 ? ($current_step == 2 ? 'current' : 'completed') : '' ?>">
                        <div class="step-icon-bubble">
                            <i class="bi bi-box-seam"></i>
                        </div>
                        <span class="step-title">Processing & Packing</span>
                        <small class="text-muted d-none d-md-block">Flock inspection / Crated</small>
                    </div>

                    <!-- Step 3: Shipped / In Transit -->
                    <div class="tracking-step <?= $current_step >= 3 ? ($current_step == 3 ? 'current' : 'completed') : '' ?>">
                        <div class="step-icon-bubble">
                            <i class="bi bi-truck"></i>
                        </div>
                        <span class="step-title">Out for Delivery</span>
                        <small class="text-muted d-none d-md-block">On delivery vehicle</small>
                    </div>

                    <!-- Step 4: Delivered -->
                    <div class="tracking-step <?= $current_step >= 4 ? 'completed' : '' ?>">
                        <div class="step-icon-bubble">
                            <i class="bi bi-house-check"></i>
                        </div>
                        <span class="step-title">Delivered</span>
                        <small class="text-muted d-none d-md-block">Arrived safely</small>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-danger text-center py-4 my-3">
                    <i class="bi bi-x-circle-fill fs-2 d-block mb-2"></i>
                    <h5 class="fw-bold">This Order Has Been Cancelled</h5>
                    <p class="small mb-0">Please contact our farm customer support hotline at <?= htmlspecialchars(get_setting('phone')) ?> for any inquiries or refund queries.</p>
                </div>
            <?php endif; ?>

            <!-- ACTIVE ORDER DETAILS & ITEMS -->
            <div class="row g-4 mt-2">
                <div class="col-md-6 border-end">
                    <h6 class="fw-bold text-secondary text-uppercase small mb-3">Delivery Information</h6>
                    <p class="mb-1"><strong>Customer:</strong> <?= htmlspecialchars($active_order['customer_name']) ?></p>
                    <p class="mb-1"><strong>Phone:</strong> <?= htmlspecialchars($active_order['customer_phone']) ?></p>
                    <p class="mb-1"><strong>Address:</strong> <?= htmlspecialchars($active_order['delivery_address']) ?></p>
                    <p class="mb-0"><strong>Payment Method:</strong> <?= htmlspecialchars($active_order['payment_method']) ?> (<?= htmlspecialchars($active_order['payment_status']) ?>)</p>
                </div>
                <div class="col-md-6">
                    <h6 class="fw-bold text-secondary text-uppercase small mb-3">Items in This Shipment</h6>
                    <ul class="list-group list-group-flush small">
                        <?php foreach ($active_items as $item): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <div>
                                    <span class="fw-bold"><?= htmlspecialchars($item['product_name']) ?></span>
                                    <span class="text-muted d-block"><?= $item['quantity'] ?> &times; <?= format_currency($item['unit_price']) ?> (<?= htmlspecialchars($item['unit']) ?>)</span>
                                </div>
                                <span class="fw-bold text-success"><?= format_currency($item['subtotal']) ?></span>
                            </li>
                        <?php endforeach; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-2 border-top">
                            <span class="fw-bold">Grand Total</span>
                            <span class="fw-bold fs-5 text-success"><?= format_currency($active_order['total_amount']) ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- ORDER HISTORY TABLE -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-header bg-white py-3">
            <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-clock-history text-success me-2"></i>Order History</h5>
        </div>

        <?php if (!empty($orders)): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-secondary">
                        <tr>
                            <th class="ps-4">Order #</th>
                            <th>Date</th>
                            <th>Recipient</th>
                            <th>Payment</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th class="pe-4 text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $ord): ?>
                            <tr class="<?= ($active_order && $active_order['id'] === $ord['id']) ? 'table-success bg-opacity-10' : '' ?>">
                                <td class="ps-4 fw-bold">
                                    <code><?= htmlspecialchars($ord['order_number']) ?></code>
                                </td>
                                <td class="small text-muted">
                                    <?= date('M d, Y', strtotime($ord['created_at'])) ?>
                                </td>
                                <td class="small">
                                    <?= htmlspecialchars($ord['customer_name']) ?>
                                </td>
                                <td class="small">
                                    <?= htmlspecialchars($ord['payment_method']) ?>
                                </td>
                                <td class="fw-bold text-success">
                                    <?= format_currency($ord['total_amount']) ?>
                                </td>
                                <td>
                                    <?php 
                                    $badge = 'bg-secondary';
                                    if ($ord['status'] === 'Pending') $badge = 'bg-warning text-dark';
                                    elseif ($ord['status'] === 'Processing') $badge = 'bg-primary';
                                    elseif ($ord['status'] === 'Shipped') $badge = 'bg-info text-dark';
                                    elseif ($ord['status'] === 'Delivered') $badge = 'bg-success';
                                    elseif ($ord['status'] === 'Cancelled') $badge = 'bg-danger';
                                    ?>
                                    <span class="badge <?= $badge ?> rounded-pill px-2 py-1">
                                        <?= htmlspecialchars($ord['status']) ?>
                                    </span>
                                </td>
                                <td class="pe-4 text-end">
                                    <a href="my-orders.php?order=<?= urlencode($ord['order_number']) ?>" class="btn btn-sm btn-outline-success rounded-pill px-3">
                                        <i class="bi bi-eye me-1"></i> Track
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="card-body text-center py-5">
                <i class="bi bi-truck fs-1 text-muted d-block mb-3"></i>
                <h5 class="fw-bold">No Orders Placed Yet</h5>
                <p class="text-muted small mb-4">When you purchase poultry, chicks, or feeds, they will appear here with live tracking.</p>
                <a href="/poultry/shop.php" class="btn btn-farm-primary px-4 py-2 rounded-pill">
                    <i class="bi bi-cart3 me-1"></i> Go to Poultry Store
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
