<?php
/**
 * Database Configuration & Connection File
 * FeatherFarm Poultry Management System
 */

// Define Database credentials
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', 'poultry_db');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_CHARSET')) define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a singleton PDO database connection instance.
 *
 * @return PDO
 */
function get_db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // If database poultry_db doesn't exist, provide a helpful redirection to setup.php
            $error_code = $e->getCode();
            $error_msg = $e->getMessage();
            
            // Check if current script is setup.php itself to prevent infinite loop
            $current_script = basename($_SERVER['PHP_SELF'] ?? '');
            if ($current_script !== 'setup.php') {
                die("
                <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 60px auto; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; background: #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.08);'>
                    <h2 style='color: #d9534f; margin-top: 0;'>Database Connection Notice</h2>
                    <p style='color: #555; line-height: 1.6;'>
                        Could not connect to the database <strong>" . htmlspecialchars(DB_NAME) . "</strong> on <strong>" . htmlspecialchars(DB_HOST) . "</strong>.
                    </p>
                    <p style='background: #f8f9fa; padding: 12px; border-left: 4px solid #d9534f; font-family: monospace; font-size: 13px; color: #333;'>
                        " . htmlspecialchars($error_msg) . "
                    </p>
                    <p style='color: #555;'>
                        If this is your first time setting up FeatherFarm, please run our 1-click automatic database installer:
                    </p>
                    <div style='margin-top: 25px;'>
                        <a href='/poultry/setup.php' style='background: #2e7d32; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;'>Run 1-Click Database Setup</a>
                        <span style='margin-left: 10px; color: #888;'>or visit <code>setup.php</code></span>
                    </div>
                </div>
                ");
            } else {
                throw $e;
            }
        }
    }
    return $pdo;
}
