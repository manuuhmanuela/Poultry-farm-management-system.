<?php
/**
 * Admin Registered Customers Directory
 * FeatherFarm Poultry Management System
 */

$page_title = 'Registered Customers';
require_once __DIR__ . '/includes/admin-header.php';

$pdo = get_db();

$search = clean_input($_GET['search'] ?? '');

// Build query to fetch customers along with their aggregate order stats
$sql = "
    SELECT 
        u.*,
        COUNT(o.id) AS total_orders,
        COALESCE(SUM(CASE WHEN o.status != 'Cancelled' THEN o.total_amount ELSE 0 END), 0) AS total_spent
    FROM `users` u
    LEFT JOIN `orders` o ON u.id = o.user_id
    WHERE u.role = 'customer'
";
$params = [];

if (!empty($search)) {
    $sql .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " GROUP BY u.id ORDER BY u.id DESC";

$customers = [];
$total_spend_all = 0.0;
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $customers = $stmt->fetchAll();

    foreach ($customers as $c) {
        $total_spend_all += (float)$c['total_spent'];
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error loading customers: " . $e->getMessage() . "</div>";
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-dark mb-1">Registered Customers Directory</h2>
        <p class="text-muted small mb-0">List of all customer accounts, contact details, total orders placed, and lifetime spend.</p>
    </div>
</div>

<!-- CUSTOMER METRICS ROW -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card kpi-card p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Total Customers</span>
                    <h3 class="fw-bold text-primary mb-0 mt-1"><?= count($customers) ?></h3>
                    <small class="text-muted">Registered accounts</small>
                </div>
                <div class="kpi-icon-box bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-people"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card kpi-card p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Customer Spend</span>
                    <h3 class="fw-bold text-success mb-0 mt-1"><?= format_currency($total_spend_all) ?></h3>
                    <small class="text-muted">Total value of orders</small>
                </div>
                <div class="kpi-icon-box bg-success bg-opacity-10 text-success">
                    <i class="bi bi-wallet2"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card kpi-card p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Avg. Value / Customer</span>
                    <h3 class="fw-bold text-info text-dark mb-0 mt-1">
                        <?= format_currency(count($customers) > 0 ? ($total_spend_all / count($customers)) : 0) ?>
                    </h3>
                    <small class="text-muted">Average customer lifetime value</small>
                </div>
                <div class="kpi-icon-box bg-info bg-opacity-10 text-info">
                    <i class="bi bi-graph-up-arrow"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- SEARCH BAR -->
<div class="card border-0 shadow-sm rounded-4 p-3 mb-4 bg-white">
    <form method="GET" action="customers.php" class="row g-2 align-items-center">
        <div class="col-md-9">
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-search text-muted"></i></span>
                <input type="text" name="search" class="form-control bg-light border-start-0" placeholder="Search customer by name, email, or telephone..." value="<?= htmlspecialchars($search) ?>">
            </div>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-farm-primary w-100">Search</button>
            <?php if (!empty($search)): ?>
                <a href="customers.php" class="btn btn-outline-secondary" title="Clear Search"><i class="bi bi-x-circle"></i></a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- CUSTOMERS TABLE -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-secondary">
                <tr>
                    <th class="ps-4">Customer Name & Contact</th>
                    <th>Email Address</th>
                    <th>Delivery Address</th>
                    <th class="text-center">Total Orders</th>
                    <th>Lifetime Spend</th>
                    <th>Registered On</th>
                    <th class="pe-4 text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($customers)): ?>
                    <?php foreach ($customers as $cust): ?>
                        <tr>
                            <td class="ps-4 py-3">
                                <div class="d-flex align-items-center">
                                    <div class="brand-icon-box bg-light text-success me-3" style="width: 42px; height: 42px; font-size: 1.2rem;">
                                        <i class="bi bi-person"></i>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark"><?= htmlspecialchars($cust['full_name']) ?></h6>
                                        <small class="text-muted"><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($cust['phone'] ?? 'No phone') ?></small>
                                    </div>
                                </div>
                            </td>

                            <td class="small">
                                <a href="mailto:<?= htmlspecialchars($cust['email']) ?>" class="text-decoration-none text-dark fw-semibold">
                                    <?= htmlspecialchars($cust['email']) ?>
                                </a>
                            </td>

                            <td class="small text-muted" style="max-width: 200px;">
                                <span class="d-inline-block text-truncate w-100" title="<?= htmlspecialchars($cust['address'] ?? 'Not specified') ?>">
                                    <?= htmlspecialchars($cust['address'] ?? 'Not specified') ?>
                                </span>
                            </td>

                            <td class="text-center">
                                <span class="badge bg-light text-dark border px-3 py-1 fw-bold fs-6">
                                    <?= $cust['total_orders'] ?>
                                </span>
                            </td>

                            <td class="fw-extrabold text-success">
                                <?= format_currency($cust['total_spent']) ?>
                            </td>

                            <td class="small text-muted">
                                <?= date('M d, Y', strtotime($cust['created_at'])) ?>
                            </td>

                            <td class="pe-4 text-end">
                                <a href="/poultry/admin/orders.php?search=<?= urlencode($cust['email']) ?>" class="btn btn-sm btn-outline-success rounded-pill px-3">
                                    <i class="bi bi-box-seam me-1"></i> Orders (<?= $cust['total_orders'] ?>)
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted">
                            <i class="bi bi-people fs-1 d-block mb-2"></i>
                            No registered customers found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
