<?php
/**
 * Admin Layout Header & Sidebar
 * FeatherFarm Poultry Management System
 */

require_once __DIR__ . '/../../includes/functions.php';

// Protect admin pages: only logged-in users with role === 'admin' can enter
require_admin();

$admin_user = current_user();
$current_page = basename($_SERVER['PHP_SELF'] ?? '');
$farm_name = get_setting('farm_name', 'FeatherFarm Poultry');
$currency = get_setting('currency', '$');
$flash = get_flash_message();

// Count pending orders for badge
$pending_orders_count = 0;
try {
    $pdo = get_db();
    $stmt = $pdo->query("SELECT COUNT(*) FROM `orders` WHERE `status` = 'Pending'");
    $pending_orders_count = (int)$stmt->fetchColumn();
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' : '' ?>Admin Portal - <?= htmlspecialchars($farm_name) ?></title>

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="/poultry/assets/css/style.css">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
            background-color: #f1f5f9;
        }
        .admin-nav-item.active {
            background-color: #e8f5e9 !important;
            color: #2e7d32 !important;
            font-weight: 700;
        }
    </style>
</head>
<body data-currency="<?= htmlspecialchars($currency) ?>">

<!-- TOP ADMIN NAVBAR -->
<nav class="navbar navbar-expand navbar-dark bg-dark sticky-top px-3 py-2 border-bottom border-secondary border-opacity-25">
    <div class="container-fluid">
        <!-- Brand -->
        <a class="navbar-brand d-flex align-items-center" href="/poultry/admin/index.php">
            <div class="brand-icon-box me-2" style="width: 36px; height: 36px; font-size: 1.1rem;">
                <i class="bi bi-egg-fried"></i>
            </div>
            <span class="fw-bold fs-5 text-white">Feather<span class="text-warning">Farm</span></span>
            <span class="badge bg-danger ms-2 small">Admin Portal</span>
        </a>

        <!-- Right: View Store & User Dropdown -->
        <div class="d-flex align-items-center gap-3 ms-auto">
            <a href="/poultry/index.php" target="_blank" class="btn btn-outline-light btn-sm rounded-pill px-3">
                <i class="bi bi-shop me-1"></i> View Live Store <i class="bi bi-box-arrow-up-right small ms-1"></i>
            </a>

            <div class="dropdown">
                <button class="btn btn-outline-secondary text-white dropdown-toggle btn-sm rounded-pill px-3 d-flex align-items-center gap-2" type="button" id="adminDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-person-circle fs-6 text-warning"></i>
                    <span class="d-none d-sm-inline"><?= htmlspecialchars($admin_user['full_name'] ?? 'Admin') ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" aria-labelledby="adminDropdown">
                    <li class="px-3 py-2 border-bottom">
                        <p class="mb-0 fw-bold"><?= htmlspecialchars($admin_user['full_name']) ?></p>
                        <p class="mb-0 small text-muted"><?= htmlspecialchars($admin_user['email']) ?></p>
                    </li>
                    <li>
                        <a class="dropdown-item py-2" href="/poultry/admin/settings.php">
                            <i class="bi bi-gear me-2"></i> Farm Settings
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item py-2 text-danger" href="/poultry/auth/logout.php">
                            <i class="bi bi-box-arrow-right me-2"></i> Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <!-- SIDEBAR NAVIGATION -->
        <nav class="col-md-3 col-lg-2 d-md-block admin-sidebar collapse p-3">
            <div class="position-sticky pt-2">
                <div class="text-uppercase small fw-bold text-muted px-3 mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">
                    Farm Operations
                </div>
                <ul class="nav flex-column mb-4">
                    <li class="nav-item">
                        <a class="nav-link admin-nav-item <?= ($current_page === 'index.php') ? 'active' : '' ?>" href="/poultry/admin/index.php">
                            <i class="bi bi-speedometer2"></i> Dashboard Overview
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link admin-nav-item <?= ($current_page === 'products.php') ? 'active' : '' ?>" href="/poultry/admin/products.php">
                            <i class="bi bi-egg"></i> Menu & Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link admin-nav-item d-flex justify-content-between align-items-center <?= ($current_page === 'orders.php') ? 'active' : '' ?>" href="/poultry/admin/orders.php">
                            <span><i class="bi bi-box-seam"></i> Customer Orders</span>
                            <?php if ($pending_orders_count > 0): ?>
                                <span class="badge bg-danger rounded-pill"><?= $pending_orders_count ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link admin-nav-item <?= ($current_page === 'customers.php') ? 'active' : '' ?>" href="/poultry/admin/customers.php">
                            <i class="bi bi-people"></i> Registered Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link admin-nav-item <?= ($current_page === 'messages.php') ? 'active' : '' ?>" href="/poultry/admin/messages.php">
                            <i class="bi bi-chat-left-text"></i> Inquiries & Messages
                        </a>
                    </li>
                </ul>

                <div class="text-uppercase small fw-bold text-muted px-3 mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">
                    System & Settings
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link admin-nav-item <?= ($current_page === 'settings.php') ? 'active' : '' ?>" href="/poultry/admin/settings.php">
                            <i class="bi bi-sliders"></i> Farm & Store Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link admin-nav-item" href="/poultry/setup.php">
                            <i class="bi bi-database-check"></i> DB Setup & Migrator
                        </a>
                    </li>
                    <li class="nav-item mt-3">
                        <a class="nav-link text-danger" href="/poultry/auth/logout.php">
                            <i class="bi bi-box-arrow-right"></i> Log Out
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- MAIN ADMIN CONTENT AREA -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <!-- FLASH NOTIFICATIONS -->
            <?php if ($flash): ?>
                <div class="alert alert-<?= htmlspecialchars($flash['type']) ?> alert-dismissible fade show shadow-sm d-flex align-items-center mb-4" role="alert">
                    <i class="bi <?= $flash['type'] === 'success' ? 'bi-check-circle-fill' : ($flash['type'] === 'danger' ? 'bi-exclamation-triangle-fill' : 'bi-info-circle-fill') ?> fs-4 me-3"></i>
                    <div><?= $flash['message'] ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
