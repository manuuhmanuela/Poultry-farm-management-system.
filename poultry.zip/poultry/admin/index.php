<?php
/**
 * Admin Dashboard Overview
 * FeatherFarm Poultry Management System
 */

$page_title = 'Dashboard Overview';
require_once __DIR__ . '/includes/admin-header.php';

$pdo = get_db();

// 1. Compute Metrics
$total_revenue = 0.0;
$total_orders = 0;
$total_customers = 0;
$total_products = 0;
$low_stock_count = 0;

try {
    // Total Revenue (excluding cancelled orders)
    $stmt = $pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM `orders` WHERE `status` != 'Cancelled'");
    $total_revenue = (float)$stmt->fetchColumn();

    // Total Orders
    $stmt = $pdo->query("SELECT COUNT(*) FROM `orders`");
    $total_orders = (int)$stmt->fetchColumn();

    // Registered Customers
    $stmt = $pdo->query("SELECT COUNT(*) FROM `users` WHERE `role` = 'customer'");
    $total_customers = (int)$stmt->fetchColumn();

    // Total Active Products
    $stmt = $pdo->query("SELECT COUNT(*) FROM `products` WHERE `status` = 'active'");
    $total_products = (int)$stmt->fetchColumn();

    // Low Stock Alert (quantity <= 10)
    $stmt = $pdo->query("SELECT COUNT(*) FROM `products` WHERE `stock_quantity` <= 10 AND `status` = 'active'");
    $low_stock_count = (int)$stmt->fetchColumn();

    // Recent 5 Orders
    $stmt = $pdo->query("SELECT * FROM `orders` ORDER BY `id` DESC LIMIT 6");
    $recent_orders = $stmt->fetchAll();

    // Low Stock Products
    $stmt = $pdo->query("SELECT p.*, c.name AS category_name FROM `products` p LEFT JOIN `categories` c ON p.category_id = c.id WHERE p.stock_quantity <= 15 ORDER BY p.stock_quantity ASC LIMIT 5");
    $low_stock_items = $stmt->fetchAll();

} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error loading dashboard statistics: " . $e->getMessage() . "</div>";
}
?>

<!-- DASHBOARD HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-dark mb-1">Farm Management Dashboard</h2>
        <p class="text-muted small mb-0">Overview of flock sales, customer orders, live inventory, and hatchery performance.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="/poultry/admin/products.php" class="btn btn-farm-primary btn-sm rounded-pill px-3">
            <i class="bi bi-plus-lg me-1"></i> Add Product / Menu
        </a>
        <a href="/poultry/admin/orders.php" class="btn btn-outline-success btn-sm rounded-pill px-3">
            <i class="bi bi-box-seam me-1"></i> View Orders
        </a>
    </div>
</div>

<!-- KPI CARDS ROW -->
<div class="row g-3 mb-4">
    <!-- Total Revenue -->
    <div class="col-sm-6 col-xl-3">
        <div class="card kpi-card p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Total Sales</span>
                    <h3 class="fw-bold text-success mb-0 mt-1"><?= format_currency($total_revenue) ?></h3>
                    <small class="text-muted"><i class="bi bi-check2 text-success"></i> Active gross revenue</small>
                </div>
                <div class="kpi-icon-box bg-success bg-opacity-10 text-success">
                    <i class="bi bi-currency-dollar"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Total Orders -->
    <div class="col-sm-6 col-xl-3">
        <div class="card kpi-card p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Customer Orders</span>
                    <h3 class="fw-bold text-primary mb-0 mt-1"><?= $total_orders ?></h3>
                    <small class="text-muted"><i class="bi bi-truck text-primary"></i> Total submitted</small>
                </div>
                <div class="kpi-icon-box bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-box-seam"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Registered Customers -->
    <div class="col-sm-6 col-xl-3">
        <div class="card kpi-card p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Registered Customers</span>
                    <h3 class="fw-bold text-info text-dark mb-0 mt-1"><?= $total_customers ?></h3>
                    <small class="text-muted"><i class="bi bi-person-check text-info"></i> Active accounts</small>
                </div>
                <div class="kpi-icon-box bg-info bg-opacity-10 text-info">
                    <i class="bi bi-people"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Low Stock Alert -->
    <div class="col-sm-6 col-xl-3">
        <div class="card kpi-card p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold">Stock Alerts</span>
                    <h3 class="fw-bold <?= $low_stock_count > 0 ? 'text-danger' : 'text-success' ?> mb-0 mt-1"><?= $low_stock_count ?></h3>
                    <small class="text-muted"><i class="bi bi-exclamation-triangle"></i> Items &le; 10 units</small>
                </div>
                <div class="kpi-icon-box <?= $low_stock_count > 0 ? 'bg-danger bg-opacity-10 text-danger' : 'bg-success bg-opacity-10 text-success' ?>">
                    <i class="bi bi-shield-exclamation"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- RECENT ORDERS TABLE -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-receipt text-success me-2"></i>Recent Orders</h5>
                <a href="/poultry/admin/orders.php" class="btn btn-sm btn-outline-success rounded-pill px-3">
                    View All Orders <i class="bi bi-arrow-right ms-1"></i>
                </a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-secondary">
                        <tr>
                            <th class="ps-4">Order #</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th class="pe-4 text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recent_orders)): ?>
                            <?php foreach ($recent_orders as $ord): ?>
                                <tr>
                                    <td class="ps-4 fw-bold">
                                        <code><?= htmlspecialchars($ord['order_number']) ?></code>
                                    </td>
                                    <td>
                                        <div class="fw-semibold small"><?= htmlspecialchars($ord['customer_name']) ?></div>
                                        <small class="text-muted"><?= htmlspecialchars($ord['customer_phone']) ?></small>
                                    </td>
                                    <td class="small text-muted">
                                        <?= date('M d, Y', strtotime($ord['created_at'])) ?>
                                    </td>
                                    <td class="fw-bold text-success">
                                        <?= format_currency($ord['total_amount']) ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $badge = 'bg-secondary';
                                        if ($ord['status'] === 'Pending') $badge = 'bg-warning text-dark';
                                        elseif ($ord['status'] === 'Processing') $badge = 'bg-primary';
                                        elseif ($ord['status'] === 'Shipped') $badge = 'bg-info text-dark';
                                        elseif ($ord['status'] === 'Delivered') $badge = 'bg-success';
                                        elseif ($ord['status'] === 'Cancelled') $badge = 'bg-danger';
                                        ?>
                                        <span class="badge <?= $badge ?> rounded-pill px-2 py-1">
                                            <?= htmlspecialchars($ord['status']) ?>
                                        </span>
                                    </td>
                                    <td class="pe-4 text-end">
                                        <a href="/poultry/admin/orders.php?highlight=<?= $ord['id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill px-2 py-1 small">
                                            <i class="bi bi-pencil-square me-1"></i> Update Status
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    No customer orders placed yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- INVENTORY & LOW STOCK SIDEBAR -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-exclamation-triangle text-warning me-2"></i>Stock Watchlist</h5>
                <a href="/poultry/admin/products.php" class="btn btn-sm btn-link text-success text-decoration-none p-0 fw-bold">Manage</a>
            </div>

            <div class="p-3">
                <?php if (!empty($low_stock_items)): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($low_stock_items as $item): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0 py-2">
                                <div>
                                    <h6 class="mb-0 small fw-bold text-dark text-truncate" style="max-width: 180px;"><?= htmlspecialchars($item['name']) ?></h6>
                                    <small class="text-muted"><?= htmlspecialchars($item['unit']) ?></small>
                                </div>
                                <span class="badge <?= $item['stock_quantity'] <= 5 ? 'bg-danger' : 'bg-warning text-dark' ?> rounded-pill">
                                    <?= $item['stock_quantity'] ?> left
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted small mb-0 text-center py-3">All poultry products are well stocked!</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- QUICK SHORTCUTS CARD -->
        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
            <h6 class="fw-bold mb-3 text-secondary text-uppercase small">Quick Farm Shortcuts</h6>
            <div class="d-grid gap-2">
                <a href="/poultry/admin/products.php" class="btn btn-outline-success text-start py-2">
                    <i class="bi bi-plus-circle me-2"></i> Add New Poultry / Feed Menu
                </a>
                <a href="/poultry/admin/customers.php" class="btn btn-outline-primary text-start py-2">
                    <i class="bi bi-people me-2"></i> Browse Registered Customers
                </a>
                <a href="/poultry/admin/settings.php" class="btn btn-outline-secondary text-start py-2">
                    <i class="bi bi-gear me-2"></i> Edit Delivery Fee & Farm Info
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
