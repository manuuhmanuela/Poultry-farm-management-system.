<?php
/**
 * Admin Contact Inquiries & Messages
 * FeatherFarm Poultry Management System
 */

$page_title = 'Customer Inquiries';
require_once __DIR__ . '/includes/admin-header.php';

$pdo = get_db();

// Handle status updates or deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $msg_id = (int)($_POST['id'] ?? 0);

    if ($msg_id > 0) {
        if ($action === 'status') {
            $new_status = clean_input($_POST['status'] ?? 'Read');
            $stmt = $pdo->prepare("UPDATE `contact_messages` SET `status` = ? WHERE `id` = ?");
            $stmt->execute([$new_status, $msg_id]);
            set_flash_message('success', 'Message status updated.');
        } elseif ($action === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM `contact_messages` WHERE `id` = ?");
            $stmt->execute([$msg_id]);
            set_flash_message('info', 'Message deleted.');
        }
    }
    header('Location: /poultry/admin/messages.php');
    exit;
}

$messages = [];
try {
    $stmt = $pdo->query("SELECT * FROM `contact_messages` ORDER BY `id` DESC");
    $messages = $stmt->fetchAll();
} catch (Exception $e) {}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-dark mb-1">Customer Inquiries & Messages</h2>
        <p class="text-muted small mb-0">Review quote requests, chick bookings, and support messages from the Contact Us form.</p>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-secondary">
                <tr>
                    <th class="ps-4">Sender Details</th>
                    <th>Subject</th>
                    <th>Message Snippet</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th class="pe-4 text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($messages)): ?>
                    <?php foreach ($messages as $m): ?>
                        <tr class="<?= $m['status'] === 'Unread' ? 'table-warning bg-opacity-10 fw-semibold' : '' ?>">
                            <td class="ps-4 py-3">
                                <div class="fw-bold text-dark"><?= htmlspecialchars($m['name']) ?></div>
                                <small class="text-muted d-block"><?= htmlspecialchars($m['email']) ?></small>
                                <?php if (!empty($m['phone'])): ?>
                                    <small class="text-muted d-block"><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($m['phone']) ?></small>
                                <?php endif; ?>
                            </td>

                            <td>
                                <span class="badge bg-light text-dark border">
                                    <?= htmlspecialchars($m['subject']) ?>
                                </span>
                            </td>

                            <td style="max-width: 300px;">
                                <p class="small text-muted mb-0 text-truncate" title="<?= htmlspecialchars($m['message']) ?>">
                                    <?= htmlspecialchars($m['message']) ?>
                                </p>
                            </td>

                            <td class="small text-muted">
                                <?= date('M d, Y h:i A', strtotime($m['created_at'])) ?>
                            </td>

                            <td>
                                <?php 
                                $badge = 'bg-secondary';
                                if ($m['status'] === 'Unread') $badge = 'bg-danger';
                                elseif ($m['status'] === 'Read') $badge = 'bg-info text-dark';
                                elseif ($m['status'] === 'Replied') $badge = 'bg-success';
                                ?>
                                <span class="badge <?= $badge ?> rounded-pill">
                                    <?= htmlspecialchars($m['status']) ?>
                                </span>
                            </td>

                            <td class="pe-4 text-end">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-primary" onclick='viewMessage(<?= json_encode($m, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)'>
                                        <i class="bi bi-eye"></i> View
                                    </button>
                                    <form method="POST" action="messages.php" class="d-inline" onsubmit="return confirm('Delete this message?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $m['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            <i class="bi bi-chat-left-text fs-1 d-block mb-2"></i>
                            No contact inquiries found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- VIEW MESSAGE MODAL -->
<div class="modal fade" id="messageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title fw-bold" id="msgModalSubject"></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="border-bottom pb-3 mb-3">
                    <p class="mb-1"><strong>From:</strong> <span id="msgModalSender"></span></p>
                    <p class="mb-1"><strong>Email:</strong> <a id="msgModalEmail" href="#"></a></p>
                    <p class="mb-0"><strong>Phone:</strong> <span id="msgModalPhone"></span></p>
                </div>
                <h6 class="fw-bold small text-secondary text-uppercase mb-2">Message Content</h6>
                <div class="p-3 bg-light rounded-3 mb-3" id="msgModalBody" style="white-space: pre-wrap;"></div>

                <form method="POST" action="messages.php" class="d-flex align-items-center gap-2">
                    <input type="hidden" name="action" value="status">
                    <input type="hidden" name="id" id="msgModalId">
                    <label class="small fw-bold">Update Status:</label>
                    <select name="status" id="msgModalStatus" class="form-select form-select-sm" style="width: 140px;">
                        <option value="Unread">Unread</option>
                        <option value="Read">Read</option>
                        <option value="Replied">Replied</option>
                    </select>
                    <button type="submit" class="btn btn-sm btn-success px-3">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function viewMessage(msg) {
    document.getElementById('msgModalId').value = msg.id;
    document.getElementById('msgModalSubject').textContent = msg.subject;
    document.getElementById('msgModalSender').textContent = msg.name;
    document.getElementById('msgModalEmail').textContent = msg.email;
    document.getElementById('msgModalEmail').href = 'mailto:' + msg.email;
    document.getElementById('msgModalPhone').textContent = msg.phone || 'N/A';
    document.getElementById('msgModalBody').textContent = msg.message;
    document.getElementById('msgModalStatus').value = msg.status;

    const modal = new bootstrap.Modal(document.getElementById('messageModal'));
    modal.show();
}
</script>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
