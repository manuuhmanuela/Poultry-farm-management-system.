<?php
/**
 * Admin Order Management & Real-time Status Updater
 * FeatherFarm Poultry Management System
 */
ob_start();
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$pdo = get_db();
// 1. Handle AJAX items request directly (before any HTML output)
if (isset($_GET['ajax_items'])) {
    $oid = (int)$_GET['ajax_items'];
    header('Content-Type: text/html; charset=utf-8');
    try {
        $stmt = $pdo->prepare("SELECT * FROM `order_items` WHERE `order_id` = ?");
        $stmt->execute([$oid]);
        $items = $stmt->fetchAll();
        if (!empty($items)) {
            echo '<table class="table table-sm align-middle mb-0">';
            echo '<thead class="table-light small"><tr><th>Item</th><th class="text-center">Unit Price</th><th class="text-center">Qty</th><th class="text-end">Subtotal</th></tr></thead><tbody>';
            $total = 0;
            foreach ($items as $it) {
                $total += $it['subtotal'];
                echo '<tr>';
                echo '<td class="fw-bold">' . htmlspecialchars($it['product_name']) . ' <small class="text-muted d-block">' . htmlspecialchars($it['unit']) . '</small></td>';
                echo '<td class="text-center">' . format_currency($it['unit_price']) . '</td>';
                echo '<td class="text-center">' . $it['quantity'] . '</td>';
                echo '<td class="text-end fw-bold text-success">' . format_currency($it['subtotal']) . '</td>';
                echo '</tr>';
            }
            echo '<tr class="table-light"><td colspan="3" class="fw-bold">Items Total:</td><td class="text-end fw-bold text-success fs-6">' . format_currency($total) . '</td></tr>';
            echo '</tbody></table>';
        } else {
            echo '<p class="text-muted mb-0">No items found for this order.</p>';
        }
    } catch (Exception $e) {
        echo '<p class="text-danger mb-0">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
    }
    exit;
}
// 2. Handle Status Update POST (before any HTML output)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $new_status = clean_input($_POST['status'] ?? '');
    $payment_status = clean_input($_POST['payment_status'] ?? '');
    $valid_statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
    if ($order_id > 0 && in_array($new_status, $valid_statuses)) {
        try {
            $stmt = $pdo->prepare("UPDATE `orders` SET `status` = ?, `payment_status` = ? WHERE `id` = ?");
            $stmt->execute([$new_status, $payment_status, $order_id]);
            set_flash_message('success', "Order #<strong>" . htmlspecialchars($_POST['order_number'] ?? $order_id) . "</strong> status updated to <span class='badge bg-success'>" . htmlspecialchars($new_status) . "</span>.");
        } catch (Exception $e) {
            set_flash_message('danger', "Error updating order status: " . $e->getMessage());
        }
    }
    header('Location: /poultry/admin/orders.php');
    exit;
}
// 3. Filter and Search parameters
$status_filter = clean_input($_GET['status'] ?? '');
$search = clean_input($_GET['search'] ?? '');
$highlight_id = (int)($_GET['highlight'] ?? 0);
$query = "SELECT * FROM `orders` WHERE 1=1";
$params = [];
if (!empty($status_filter)) {
    $query .= " AND `status` = ?";
    $params[] = $status_filter;
}
if (!empty($search)) {
    $query .= " AND (`order_number` LIKE ? OR `customer_name` LIKE ? OR `customer_phone` LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$query .= " ORDER BY `id` DESC";
$orders = [];
try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $orders = $stmt->fetchAll();
} catch (Exception $e) {}
// Count orders by status for badge tabs
$counts = ['All' => 0, 'Pending' => 0, 'Processing' => 0, 'Shipped' => 0, 'Delivered' => 0, 'Cancelled' => 0];
try {
    $stmt = $pdo->query("SELECT `status`, COUNT(*) as cnt FROM `orders` GROUP BY `status`");
    while ($row = $stmt->fetch()) {
        $counts[$row['status']] = (int)$row['cnt'];
        $counts['All'] += (int)$row['cnt'];
    }
} catch (Exception $e) {}
// 4. Require Header only when rendering the page
$page_title = 'Customer Orders';
require_once __DIR__ . '/includes/admin-header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-dark mb-1">Customer Orders Management</h2>
        <p class="text-muted small mb-0">Update delivery statuses, view flock line-items, and track order fulfillment.</p>
    </div>
</div>
<!-- STATUS FILTER PILLS -->
<div class="d-flex flex-wrap gap-2 mb-4">
    <a href="orders.php" class="btn btn-sm rounded-pill px-3 fw-bold <?= empty($status_filter) ? 'btn-success text-white' : 'btn-outline-secondary' ?>">
        All Orders <span class="badge bg-white text-dark ms-1"><?= $counts['All'] ?></span>
    </a>
    <a href="orders.php?status=Pending" class="btn btn-sm rounded-pill px-3 fw-bold <?= $status_filter === 'Pending' ? 'btn-warning text-dark' : 'btn-outline-secondary' ?>">
        <i class="bi bi-clock me-1"></i> Pending <span class="badge bg-danger ms-1"><?= $counts['Pending'] ?></span>
    </a>
    <a href="orders.php?status=Processing" class="btn btn-sm rounded-pill px-3 fw-bold <?= $status_filter === 'Processing' ? 'btn-primary text-white' : 'btn-outline-secondary' ?>">
        <i class="bi bi-box-seam me-1"></i> Processing <span class="badge bg-white text-dark ms-1"><?= $counts['Processing'] ?></span>
    </a>
    <a href="orders.php?status=Shipped" class="btn btn-sm rounded-pill px-3 fw-bold <?= $status_filter === 'Shipped' ? 'btn-info text-dark' : 'btn-outline-secondary' ?>">
        <i class="bi bi-truck me-1"></i> Shipped <span class="badge bg-white text-dark ms-1"><?= $counts['Shipped'] ?></span>
    </a>
    <a href="orders.php?status=Delivered" class="btn btn-sm rounded-pill px-3 fw-bold <?= $status_filter === 'Delivered' ? 'btn-success text-white' : 'btn-outline-secondary' ?>">
        <i class="bi bi-check-circle me-1"></i> Delivered <span class="badge bg-white text-dark ms-1"><?= $counts['Delivered'] ?></span>
    </a>
    <a href="orders.php?status=Cancelled" class="btn btn-sm rounded-pill px-3 fw-bold <?= $status_filter === 'Cancelled' ? 'btn-danger text-white' : 'btn-outline-secondary' ?>">
        <i class="bi bi-x-circle me-1"></i> Cancelled <span class="badge bg-white text-dark ms-1"><?= $counts['Cancelled'] ?></span>
    </a>
</div>
<!-- SEARCH BAR -->
<div class="card border-0 shadow-sm rounded-4 p-3 mb-4 bg-white">
    <form method="GET" action="orders.php" class="row g-2 align-items-center">
        <?php if (!empty($status_filter)): ?>
            <input type="hidden" name="status" value="<?= htmlspecialchars($status_filter) ?>">
        <?php endif; ?>
        <div class="col-md-9">
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-search text-muted"></i></span>
                <input type="text" name="search" class="form-control bg-light border-start-0" placeholder="Search by Order # (ORD-...), Customer Name, or Phone..." value="<?= htmlspecialchars($search) ?>">
            </div>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-farm-primary w-100">Search Orders</button>
            <?php if (!empty($search)): ?>
                <a href="orders.php<?= !empty($status_filter) ? '?status=' . urlencode($status_filter) : '' ?>" class="btn btn-outline-secondary" title="Clear Search"><i class="bi bi-x-circle"></i></a>
            <?php endif; ?>
        </div>
    </form>
</div>
<!-- ORDERS TABLE -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-secondary">
                <tr>
                    <th class="ps-4">Order Details</th>
                    <th>Customer & Address</th>
                    <th>Payment</th>
                    <th>Total</th>
                    <th>Current Status</th>
                    <th class="pe-4 text-end">Update Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($orders)): ?>
                    <?php foreach ($orders as $ord): ?>
                        <tr class="<?= ($highlight_id === (int)$ord['id']) ? 'table-warning bg-opacity-25' : '' ?>">
                            <td class="ps-4 py-3">
                                <span class="fw-bold text-dark d-block">
                                    <code><?= htmlspecialchars($ord['order_number']) ?></code>
                                </span>
                                <small class="text-muted"><i class="bi bi-calendar3 me-1"></i><?= date('M d, Y h:i A', strtotime($ord['created_at'])) ?></small>
                                <?php if (!empty($ord['notes'])): ?>
                                    <small class="d-block text-secondary fst-italic mt-1" title="Customer Note">
                                        <i class="bi bi-chat-quote me-1"></i>"<?= htmlspecialchars($ord['notes']) ?>"
                                    </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($ord['customer_name']) ?></div>
                                <small class="text-muted d-block"><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($ord['customer_phone']) ?></small>
                                <small class="text-muted d-block text-truncate" style="max-width: 240px;" title="<?= htmlspecialchars($ord['delivery_address']) ?>">
                                    <i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($ord['delivery_address']) ?>
                                </small>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border"><?= htmlspecialchars($ord['payment_method']) ?></span>
                                <small class="d-block <?= $ord['payment_status'] === 'Paid' ? 'text-success fw-bold' : 'text-muted' ?>">
                                    <?= htmlspecialchars($ord['payment_status']) ?>
                                </small>
                            </td>
                            <td class="fw-extrabold text-success">
                                <?= format_currency($ord['total_amount']) ?>
                                <small class="text-muted d-block fw-normal" style="font-size: 0.72rem;">(Del: <?= $ord['delivery_fee'] == 0 ? 'Free' : format_currency($ord['delivery_fee']) ?>)</small>
                            </td>
                            <td>
                                <?php 
                                $badge = 'bg-secondary';
                                if ($ord['status'] === 'Pending') $badge = 'bg-warning text-dark';
                                elseif ($ord['status'] === 'Processing') $badge = 'bg-primary';
                                elseif ($ord['status'] === 'Shipped') $badge = 'bg-info text-dark';
                                elseif ($ord['status'] === 'Delivered') $badge = 'bg-success';
                                elseif ($ord['status'] === 'Cancelled') $badge = 'bg-danger';
                                ?>
                                <span class="badge <?= $badge ?> rounded-pill px-3 py-2 fs-6">
                                    <?= htmlspecialchars($ord['status']) ?>
                                </span>
                            </td>
                            <td class="pe-4 text-end">
                                <div class="d-flex justify-content-end gap-2">
                                    <!-- View Items Button -->
                                    <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill" onclick="viewOrderItems(<?= $ord['id'] ?>, '<?= htmlspecialchars(addslashes($ord['order_number'])) ?>')">
                                        <i class="bi bi-list-check me-1"></i> Items
                                    </button>
                                    <!-- Quick Update Status Dropdown / Modal Trigger -->
                                    <button type="button" class="btn btn-sm btn-farm-primary rounded-pill px-3" onclick='openStatusModal(<?= json_encode($ord, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)'>
                                        <i class="bi bi-arrow-repeat me-1"></i> Update Status
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                            No orders found under this status filter.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- ==============================================
     UPDATE ORDER STATUS MODAL
     ============================================== -->
<div class="modal fade" id="updateStatusModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title fw-bold"><i class="bi bi-arrow-repeat me-2"></i>Update Order Status</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="orders.php">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="order_id" id="modal_order_id">
                <input type="hidden" name="order_number" id="modal_order_number_hidden">
                <div class="modal-body p-4">
                    <div class="alert alert-light border mb-3">
                        <small class="text-muted d-block">Modifying Order:</small>
                        <h5 class="fw-bold mb-0 text-success" id="modal_order_number"></h5>
                        <p class="small text-muted mb-0" id="modal_customer_info"></p>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Fulfillment & Delivery Status <span class="text-danger">*</span></label>
                        <select name="status" id="modal_status" class="form-select form-select-lg">
                            <option value="Pending">1. Pending (Order Placed / Awaiting Farm Confirmation)</option>
                            <option value="Processing">2. Processing (Packaging Flock / Preparing Crates)</option>
                            <option value="Shipped">3. Shipped (Dispatched on Delivery Truck)</option>
                            <option value="Delivered">4. Delivered (Completed / Handed Over to Customer)</option>
                            <option value="Cancelled">5. Cancelled (Revoked / Out of Stock)</option>
                        </select>
                        <div class="form-text small">
                            Updating status instantly changes the 4-step tracking progress bar in the customer's portal!
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label fw-semibold small">Payment Status</label>
                        <select name="payment_status" id="modal_payment_status" class="form-select">
                            <option value="Pending">Pending</option>
                            <option value="Paid">Paid</option>
                            <option value="Failed">Failed</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success px-4 fw-bold">Save Status Change</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- ==============================================
     VIEW ORDER ITEMS MODAL
     ============================================== -->
<div class="modal fade" id="orderItemsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title fw-bold" id="itemsModalTitle"><i class="bi bi-basket2 me-2"></i>Ordered Poultry Items</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4" id="itemsModalContent">
                <div class="text-center py-4">
                    <div class="spinner-border text-success" role="status"></div>
                    <p class="small text-muted mt-2">Loading flock line items...</p>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
function openStatusModal(order) {
    document.getElementById('modal_order_id').value = order.id;
    document.getElementById('modal_order_number_hidden').value = order.order_number;
    document.getElementById('modal_order_number').textContent = order.order_number;
    document.getElementById('modal_customer_info').textContent = order.customer_name + ' (' + order.customer_phone + ')';
    document.getElementById('modal_status').value = order.status;
    document.getElementById('modal_payment_status').value = order.payment_status;
    const modal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
    modal.show();
}
function viewOrderItems(orderId, orderNumber) {
    document.getElementById('itemsModalTitle').innerHTML = `<i class="bi bi-basket2 me-2"></i>Items in Order: <code>${orderNumber}</code>`;
    const content = document.getElementById('itemsModalContent');
    content.innerHTML = `<div class="text-center py-4"><div class="spinner-border text-success" role="status"></div><p class="small text-muted mt-2">Loading items...</p></div>`;
    const modal = new bootstrap.Modal(document.getElementById('orderItemsModal'));
    modal.show();
    // Fetch items via AJAX from lightweight helper
    fetch('/poultry/admin/orders.php?ajax_items=' + orderId)
    .then(res => res.text())
    .then(html => {
        content.innerHTML = html;
    })
    .catch(err => {
        content.innerHTML = `<div class="alert alert-danger">Error loading items: ${err}</div>`;
    });
}
</script>
<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>