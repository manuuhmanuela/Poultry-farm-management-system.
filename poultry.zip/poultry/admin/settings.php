<?php
/**
 * Admin Farm & Store Settings
 * FeatherFarm Poultry Management System
 */

$page_title = 'Farm & Store Settings';
require_once __DIR__ . '/includes/admin-header.php';

$pdo = get_db();
$admin_user = current_user();

// Handle Settings Update POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_settings') {
        $farm_name = clean_input($_POST['farm_name'] ?? '');
        $farm_tagline = clean_input($_POST['farm_tagline'] ?? '');
        $phone = clean_input($_POST['phone'] ?? '');
        $email = clean_input($_POST['email'] ?? '');
        $address = clean_input($_POST['address'] ?? '');
        $working_hours = clean_input($_POST['working_hours'] ?? '');
        $currency = clean_input($_POST['currency'] ?? '$');
        $delivery_fee = (float)($_POST['delivery_fee'] ?? 0);
        $free_delivery_threshold = (float)($_POST['free_delivery_threshold'] ?? 100);

        $settings_to_update = [
            'farm_name' => $farm_name,
            'farm_tagline' => $farm_tagline,
            'phone' => $phone,
            'email' => $email,
            'address' => $address,
            'working_hours' => $working_hours,
            'currency' => $currency,
            'delivery_fee' => number_format($delivery_fee, 2, '.', ''),
            'free_delivery_threshold' => number_format($free_delivery_threshold, 2, '.', '')
        ];

        try {
            $stmt = $pdo->prepare("INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`)");
            foreach ($settings_to_update as $k => $v) {
                $stmt->execute([$k, $v]);
            }
            set_flash_message('success', 'Farm configuration & e-commerce settings saved successfully.');
        } catch (Exception $e) {
            set_flash_message('danger', 'Error updating settings: ' . $e->getMessage());
        }
        header('Location: /poultry/admin/settings.php');
        exit;
    }
    elseif ($action === 'change_password') {
        $current_pass = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        try {
            // Fetch current stored password
            $stmt = $pdo->prepare("SELECT `password` FROM `users` WHERE `id` = ?");
            $stmt->execute([$admin_user['id']]);
            $stored_pass = $stmt->fetchColumn();

            $current_matches = ($current_pass === $stored_pass) || password_verify($current_pass, $stored_pass);

            if (!$current_matches) {
                set_flash_message('danger', 'Incorrect current password provided.');
            } elseif (strlen($new_pass) < 6) {
                set_flash_message('danger', 'New password must be at least 6 characters.');
            } elseif ($new_pass !== $confirm_pass) {
                set_flash_message('danger', 'New passwords do not match.');
            } else {
                // Save new admin password in plain text as requested
                $stmt = $pdo->prepare("UPDATE `users` SET `password` = ? WHERE `id` = ?");
                $stmt->execute([$new_pass, $admin_user['id']]);
                set_flash_message('success', 'Administrator password changed successfully (stored unhashed).');
            }
        } catch (Exception $e) {
            set_flash_message('danger', 'Error updating password: ' . $e->getMessage());
        }
        header('Location: /poultry/admin/settings.php');
        exit;
    }
}

// Fetch all current settings
$settings = [];
try {
    $stmt = $pdo->query("SELECT `setting_key`, `setting_value` FROM `settings`");
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (Exception $e) {}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-dark mb-1">Farm & Store Settings</h2>
        <p class="text-muted small mb-0">Configure your farm branding, currency, flat shipping fees, and admin password.</p>
    </div>
</div>

<div class="row g-4">
    <!-- GENERAL FARM & STORE SETTINGS FORM -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5 bg-white">
            <h5 class="fw-bold text-dark mb-3 d-flex align-items-center">
                <i class="bi bi-shop text-success me-2 fs-4"></i> Farm Profile & Store Configuration
            </h5>
            <hr class="mb-4">

            <form method="POST" action="settings.php">
                <input type="hidden" name="action" value="save_settings">

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Farm / Business Name</label>
                        <input type="text" name="farm_name" class="form-control" value="<?= htmlspecialchars($settings['farm_name'] ?? 'FeatherFarm Poultry') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Currency Symbol</label>
                        <input type="text" name="currency" class="form-control" value="<?= htmlspecialchars($settings['currency'] ?? '$') ?>" placeholder="$, KSh, ₦, €, £, etc." required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold small">Farm Tagline / Mission</label>
                    <input type="text" name="farm_tagline" class="form-control" value="<?= htmlspecialchars($settings['farm_tagline'] ?? '') ?>" placeholder="Fresh, Healthy & Organically Raised Poultry Direct From Our Hatchery">
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Contact Phone / WhatsApp</label>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($settings['phone'] ?? '+1 (555) 789-2345') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Contact Email Address</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($settings['email'] ?? 'info@poultryfarm.com') ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold small">Physical Farm Location / Hub Address</label>
                    <textarea name="address" class="form-control" rows="2" required><?= htmlspecialchars($settings['address'] ?? 'Plot 42 Green Valley Rd, CA') ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold small">Operating & Working Hours</label>
                    <input type="text" name="working_hours" class="form-control" value="<?= htmlspecialchars($settings['working_hours'] ?? 'Mon - Sat: 7:00 AM - 6:00 PM') ?>" required>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Flat Delivery Fee</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light"><?= htmlspecialchars($settings['currency'] ?? '$') ?></span>
                            <input type="number" step="0.01" min="0" name="delivery_fee" class="form-control" value="<?= htmlspecialchars($settings['delivery_fee'] ?? '5.00') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Free Delivery Order Threshold</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light"><?= htmlspecialchars($settings['currency'] ?? '$') ?></span>
                            <input type="number" step="0.01" min="0" name="free_delivery_threshold" class="form-control" value="<?= htmlspecialchars($settings['free_delivery_threshold'] ?? '100.00') ?>" required>
                        </div>
                        <div class="form-text small">Orders above this amount qualify for zero delivery fees.</div>
                    </div>
                </div>

                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-farm-primary px-4 py-2 fw-bold">
                        <i class="bi bi-save me-2"></i> Save Store Settings
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- ADMIN PASSWORD CHANGE FORM -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
            <h5 class="fw-bold text-dark mb-3 d-flex align-items-center">
                <i class="bi bi-shield-lock text-danger me-2 fs-4"></i> Security Settings
            </h5>
            <hr class="mb-3">

            <form method="POST" action="settings.php">
                <input type="hidden" name="action" value="change_password">

                <div class="mb-3">
                    <label class="form-label fw-semibold small">Current Password</label>
                    <input type="password" name="current_password" class="form-control" placeholder="••••••••" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold small">New Password</label>
                    <input type="password" name="new_password" class="form-control" placeholder="At least 6 chars" required minlength="6">
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold small">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password" required>
                </div>

                <div class="d-grid">
                    <button type="submit" class="btn btn-outline-danger py-2 fw-semibold">
                        <i class="bi bi-key me-1"></i> Update Admin Password
                    </button>
                </div>
            </form>
        </div>

        <!-- DATABASE STATUS CARD -->
        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
            <h6 class="fw-bold text-secondary text-uppercase small mb-2">Database Tools</h6>
            <p class="small text-muted mb-3">Need to re-seed demo birds, reset default accounts, or inspect tables?</p>
            <a href="/poultry/setup.php" target="_blank" class="btn btn-outline-success btn-sm w-100 py-2">
                <i class="bi bi-database me-1"></i> Open Database Setup Wizard
            </a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
