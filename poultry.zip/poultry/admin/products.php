<?php
/**
 * Admin Product / Menu Management (Add, Edit, Delete Poultry Items)
 * FeatherFarm Poultry Management System
 */

$page_title = 'Poultry Menu & Products';
require_once __DIR__ . '/includes/admin-header.php';

$pdo = get_db();

// Handle Form Submissions (Create, Edit, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = clean_input($_POST['name'] ?? '');
        $category_id = (int)($_POST['category_id'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        $unit = clean_input($_POST['unit'] ?? 'unit');
        $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
        $image_url = clean_input($_POST['image_url'] ?? '');
        $description = clean_input($_POST['description'] ?? '');
        $featured = isset($_POST['featured']) ? 1 : 0;
        $status = clean_input($_POST['status'] ?? 'active');

        // Generate slug
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        // Check uniqueness of slug
        $slug .= '-' . rand(100, 999);

        if (!empty($name) && $category_id > 0 && $price > 0) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO `products` 
                    (`category_id`, `name`, `slug`, `price`, `unit`, `stock_quantity`, `image_url`, `description`, `featured`, `status`) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $category_id, $name, $slug, $price, $unit, $stock_quantity, $image_url, $description, $featured, $status
                ]);
                set_flash_message('success', "New poultry menu item <strong>" . htmlspecialchars($name) . "</strong> has been created.");
            } catch (Exception $e) {
                set_flash_message('danger', "Error adding product: " . $e->getMessage());
            }
        } else {
            set_flash_message('danger', "Please complete all required fields (Name, Category, Price).");
        }
        header('Location: /poultry/admin/products.php');
        exit;
    }
    elseif ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $name = clean_input($_POST['name'] ?? '');
        $category_id = (int)($_POST['category_id'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        $unit = clean_input($_POST['unit'] ?? 'unit');
        $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
        $image_url = clean_input($_POST['image_url'] ?? '');
        $description = clean_input($_POST['description'] ?? '');
        $featured = isset($_POST['featured']) ? 1 : 0;
        $status = clean_input($_POST['status'] ?? 'active');

        if ($id > 0 && !empty($name) && $category_id > 0) {
            try {
                $stmt = $pdo->prepare("
                    UPDATE `products` 
                    SET `category_id` = ?, `name` = ?, `price` = ?, `unit` = ?, `stock_quantity` = ?, `image_url` = ?, `description` = ?, `featured` = ?, `status` = ? 
                    WHERE `id` = ?
                ");
                $stmt->execute([
                    $category_id, $name, $price, $unit, $stock_quantity, $image_url, $description, $featured, $status, $id
                ]);
                set_flash_message('success', "Product <strong>" . htmlspecialchars($name) . "</strong> successfully updated.");
            } catch (Exception $e) {
                set_flash_message('danger', "Error updating product: " . $e->getMessage());
            }
        }
        header('Location: /poultry/admin/products.php');
        exit;
    }
    elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare("DELETE FROM `products` WHERE `id` = ?");
                $stmt->execute([$id]);
                set_flash_message('info', "Product deleted from inventory.");
            } catch (Exception $e) {
                set_flash_message('danger', "Error deleting product: " . $e->getMessage());
            }
        }
        header('Location: /poultry/admin/products.php');
        exit;
    }
}

// Fetch categories for select menus
$categories = [];
try {
    $stmt = $pdo->query("SELECT * FROM `categories` ORDER BY `name` ASC");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {}

// Fetch products with category names
$search = clean_input($_GET['search'] ?? '');
$cat_filter = (int)($_GET['category_id'] ?? 0);

$query = "SELECT p.*, c.name AS category_name FROM `products` p LEFT JOIN `categories` c ON p.category_id = c.id WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (p.name LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($cat_filter > 0) {
    $query .= " AND p.category_id = ?";
    $params[] = $cat_filter;
}

$query .= " ORDER BY p.id DESC";

$products = [];
try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
} catch (Exception $e) {}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-dark mb-1">Poultry Menu & Products</h2>
        <p class="text-muted small mb-0">Manage live birds, eggs, day-old chicks, feeds, pricing, and stock inventory.</p>
    </div>
    <!-- Button Trigger Modal -->
    <button type="button" class="btn btn-farm-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addProductModal">
        <i class="bi bi-plus-circle me-2"></i> Add New Product / Menu Item
    </button>
</div>

<!-- SEARCH & FILTER ROW -->
<div class="card border-0 shadow-sm rounded-4 p-3 mb-4 bg-white">
    <form method="GET" action="products.php" class="row g-3 align-items-center">
        <div class="col-md-6 col-lg-5">
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-search text-muted"></i></span>
                <input type="text" name="search" class="form-control bg-light border-start-0" placeholder="Search by product name..." value="<?= htmlspecialchars($search) ?>">
            </div>
        </div>
        <div class="col-md-4 col-lg-4">
            <select name="category_id" class="form-select bg-light" onchange="this.form.submit()">
                <option value="0">All Categories</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $cat_filter === (int)$c['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2 col-lg-3 d-flex gap-2">
            <button type="submit" class="btn btn-outline-success w-100">Filter</button>
            <?php if (!empty($search) || $cat_filter > 0): ?>
                <a href="products.php" class="btn btn-outline-secondary" title="Clear Filters"><i class="bi bi-x-circle"></i></a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- PRODUCTS TABLE -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-secondary">
                <tr>
                    <th class="ps-4">Product Details</th>
                    <th>Category</th>
                    <th>Unit Price</th>
                    <th>Stock Level</th>
                    <th>Status</th>
                    <th class="pe-4 text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($products)): ?>
                    <?php foreach ($products as $p): ?>
                        <tr>
                            <td class="ps-4 py-3">
                                <div class="d-flex align-items-center">
                                    <img src="<?= htmlspecialchars($p['image_url'] ?? 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=150&q=80') ?>" class="rounded-3 me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark"><?= htmlspecialchars($p['name']) ?></h6>
                                        <small class="text-muted"><?= htmlspecialchars($p['unit']) ?></small>
                                        <?php if ($p['featured']): ?>
                                            <span class="badge bg-warning text-dark ms-1" style="font-size: 0.65rem;">Featured</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border">
                                    <?= htmlspecialchars($p['category_name'] ?? 'General') ?>
                                </span>
                            </td>
                            <td class="fw-bold text-success">
                                <?= format_currency($p['price']) ?>
                            </td>
                            <td>
                                <?php if ($p['stock_quantity'] > 15): ?>
                                    <span class="badge bg-success rounded-pill"><?= $p['stock_quantity'] ?> in stock</span>
                                <?php elseif ($p['stock_quantity'] > 0): ?>
                                    <span class="badge bg-warning text-dark rounded-pill"><?= $p['stock_quantity'] ?> low stock</span>
                                <?php else: ?>
                                    <span class="badge bg-danger rounded-pill">0 out of stock</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?= $p['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                    <?= ucfirst($p['status']) ?>
                                </span>
                            </td>
                            <td class="pe-4 text-end">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                            onclick='editProduct(<?= json_encode($p, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)'>
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger" 
                                            onclick="confirmDelete(<?= $p['id'] ?>, '<?= htmlspecialchars(addslashes($p['name'])) ?>')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            <i class="bi bi-egg fs-1 d-block mb-2"></i>
                            No poultry products match your query.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==============================================
     ADD PRODUCT MODAL ("ADD MENU")
     ============================================== -->
<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title fw-bold" id="addProductModalLabel"><i class="bi bi-plus-circle me-2"></i>Add New Poultry Item / Menu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="products.php">
                <input type="hidden" name="action" value="create">
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label fw-semibold small">Product Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="e.g. Kuroiler Dual-Purpose Hens" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Category <span class="text-danger">*</span></label>
                            <select name="category_id" class="form-select" required>
                                <option value="">Select Category...</option>
                                <?php foreach ($categories as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Price (<?= htmlspecialchars($currency) ?>) <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0" name="price" class="form-control" placeholder="15.00" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Unit Type <span class="text-danger">*</span></label>
                            <input type="text" name="unit" class="form-control" placeholder="e.g. per bird, per crate, per 50kg bag" value="per bird" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Initial Stock Quantity <span class="text-danger">*</span></label>
                            <input type="number" min="0" name="stock_quantity" class="form-control" placeholder="100" value="50" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold small">Image URL</label>
                            <input type="url" name="image_url" class="form-control" placeholder="https://images.unsplash.com/photo-..." value="https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=600&q=80">
                            <small class="text-muted">Enter a direct image link or Unsplash photo link.</small>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold small">Description</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="Provide breeding details, vaccination history, or feed specs..."></textarea>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Catalog Status</label>
                            <select name="status" class="form-select">
                                <option value="active">Active (Available for purchase)</option>
                                <option value="inactive">Inactive (Hidden from store)</option>
                            </select>
                        </div>
                        <div class="col-md-6 d-flex align-items-center pt-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="featured" id="featuredCheck" value="1">
                                <label class="form-check-label fw-semibold small" for="featuredCheck">
                                    Display in Home Page Featured Carousel
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-farm-primary px-4">Save Poultry Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ==============================================
     EDIT PRODUCT MODAL
     ============================================== -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold" id="editProductModalLabel"><i class="bi bi-pencil-square me-2"></i>Edit Poultry Product</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="products.php">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label fw-semibold small">Product Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="edit_name" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Category <span class="text-danger">*</span></label>
                            <select name="category_id" id="edit_category_id" class="form-select" required>
                                <?php foreach ($categories as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Price (<?= htmlspecialchars($currency) ?>) <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0" name="price" id="edit_price" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Unit Type <span class="text-danger">*</span></label>
                            <input type="text" name="unit" id="edit_unit" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Stock Quantity <span class="text-danger">*</span></label>
                            <input type="number" min="0" name="stock_quantity" id="edit_stock" class="form-control" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold small">Image URL</label>
                            <input type="url" name="image_url" id="edit_image_url" class="form-control">
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold small">Description</label>
                            <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Status</label>
                            <select name="status" id="edit_status" class="form-select">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="col-md-6 d-flex align-items-center pt-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="featured" id="edit_featured" value="1">
                                <label class="form-check-label fw-semibold small" for="edit_featured">
                                    Display in Home Page Featured Carousel
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4">Update Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ==============================================
     DELETE CONFIRMATION MODAL
     ============================================== -->
<div class="modal fade" id="deleteProductModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title fw-bold"><i class="bi bi-exclamation-triangle me-2"></i>Confirm Delete</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="products.php">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                <div class="modal-body p-4 text-center">
                    <p class="mb-2">Are you sure you want to remove <strong id="delete_product_name"></strong> from your poultry menu?</p>
                    <p class="text-danger small mb-0">This will remove it from customer catalog view.</p>
                </div>
                <div class="modal-footer bg-light justify-content-center">
                    <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger px-4">Yes, Delete Item</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editProduct(product) {
    document.getElementById('edit_id').value = product.id;
    document.getElementById('edit_name').value = product.name;
    document.getElementById('edit_category_id').value = product.category_id;
    document.getElementById('edit_price').value = product.price;
    document.getElementById('edit_unit').value = product.unit;
    document.getElementById('edit_stock').value = product.stock_quantity;
    document.getElementById('edit_image_url').value = product.image_url || '';
    document.getElementById('edit_description').value = product.description || '';
    document.getElementById('edit_status').value = product.status;
    document.getElementById('edit_featured').checked = parseInt(product.featured) === 1;

    const modal = new bootstrap.Modal(document.getElementById('editProductModal'));
    modal.show();
}

function confirmDelete(id, name) {
    document.getElementById('delete_id').value = id;
    document.getElementById('delete_product_name').textContent = name;

    const modal = new bootstrap.Modal(document.getElementById('deleteProductModal'));
    modal.show();
}
</script>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
