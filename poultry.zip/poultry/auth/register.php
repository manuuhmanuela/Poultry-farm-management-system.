<?php
/**
 * Customer Registration Page
 * FeatherFarm Poultry Management System
 */

$page_title = 'Register Account';
require_once __DIR__ . '/../includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    header('Location: /poultry/shop.php');
    exit;
}

$error = '';
$full_name = '';
$email = '';
$phone = '';
$address = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = clean_input($_POST['full_name'] ?? '');
    $email = clean_input($_POST['email'] ?? '');
    $phone = clean_input($_POST['phone'] ?? '');
    $address = clean_input($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (empty($full_name) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields (Name, Email, Password).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please provide a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $password_confirm) {
        $error = 'Password confirmation does not match.';
    } else {
        try {
            $pdo = get_db();
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT `id` FROM `users` WHERE `email` = ? LIMIT 1");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'This email address is already registered. Please sign in or use another email.';
            } else {
                // Hash password with bcrypt
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO `users` (`full_name`, `email`, `password`, `role`, `phone`, `address`) VALUES (?, ?, ?, 'customer', ?, ?)");
                $stmt->execute([$full_name, $email, $hashed_password, $phone, $address]);

                $new_user_id = $pdo->lastInsertId();

                // Log the user in automatically
                $_SESSION['user'] = [
                    'id' => $new_user_id,
                    'full_name' => $full_name,
                    'email' => $email,
                    'role' => 'customer',
                    'phone' => $phone,
                    'address' => $address
                ];

                set_flash_message('success', "Welcome to FeatherFarm, <strong>" . htmlspecialchars($full_name) . "</strong>! Your account has been created.");
                header('Location: /poultry/shop.php');
                exit;
            }
        } catch (Exception $e) {
            $error = 'Registration failed: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5 my-md-3">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-success text-white text-center py-4">
                    <div class="brand-icon-box mx-auto mb-2 bg-white text-success">
                        <i class="bi bi-person-plus fs-3"></i>
                    </div>
                    <h4 class="fw-bold mb-1">Create Customer Account</h4>
                    <p class="mb-0 small text-white-50">Join FeatherFarm to order fresh poultry & track deliveries</p>
                </div>

                <div class="card-body p-4 p-md-5">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                            <i class="bi bi-exclamation-triangle-fill fs-5 me-2"></i>
                            <div><?= $error ?></div>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="register.php" class="needs-validation">
                        <div class="mb-3">
                            <label for="full_name" class="form-label fw-semibold">Full Name <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-person"></i></span>
                                <input type="text" class="form-control" id="full_name" name="full_name" value="<?= htmlspecialchars($full_name) ?>" placeholder="e.g. John Doe" required autofocus>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label for="email" class="form-label fw-semibold">Email Address <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email) ?>" placeholder="name@example.com" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="phone" class="form-label fw-semibold">Phone Number</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-telephone"></i></span>
                                    <input type="tel" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($phone) ?>" placeholder="+1 (555) 000-0000">
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label fw-semibold">Default Delivery Address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-geo-alt"></i></span>
                                <input type="text" class="form-control" id="address" name="address" value="<?= htmlspecialchars($address) ?>" placeholder="Street name, City, State / Zip">
                            </div>
                            <div class="form-text small">Used to auto-fill delivery details during checkout.</div>
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label for="password" class="form-label fw-semibold">Password <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-key"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="At least 6 chars" required minlength="6">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="password_confirm" class="form-label fw-semibold">Confirm Password <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-check2-circle"></i></span>
                                    <input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="Repeat password" required>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-farm-primary py-2 fs-6">
                                <i class="bi bi-person-check-fill me-2"></i> Register & Start Shopping
                            </button>
                        </div>

                        <div class="text-center text-muted small">
                            Already have an account? 
                            <a href="login.php" class="text-success fw-bold text-decoration-none">Sign In Here</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
