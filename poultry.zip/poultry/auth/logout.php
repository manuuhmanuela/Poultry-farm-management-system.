<?php
/**
 * User Logout Script
 * FeatherFarm Poultry Management System
 */

require_once __DIR__ . '/../includes/functions.php';

// Unset user session
if (isset($_SESSION['user'])) {
    unset($_SESSION['user']);
}

set_flash_message('info', 'You have been successfully signed out.');
header('Location: /poultry/index.php');
exit;
