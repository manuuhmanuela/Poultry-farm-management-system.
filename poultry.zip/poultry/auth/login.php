<?php
/**
 * User & Administrator Login
 * FeatherFarm Poultry Management System
 */

$page_title = 'Sign In';
require_once __DIR__ . '/../includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    if (is_admin()) {
        header('Location: /poultry/admin/index.php');
    } else {
        header('Location: /poultry/shop.php');
    }
    exit;
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean_input($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both your email address and password.';
    } else {
        try {
            $pdo = get_db();
            $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            $password_valid = false;
            if ($user) {
                // Check plain text match first, then bcrypt fallback
                if ($user['password'] === $password) {
                    $password_valid = true;
                } elseif (password_verify($password, $user['password'])) {
                    $password_valid = true;
                }
            }

            if ($user && $password_valid) {
                // Successful authentication
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'full_name' => $user['full_name'],
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'phone' => $user['phone'],
                    'address' => $user['address']
                ];

                set_flash_message('success', "Welcome back, <strong>" . htmlspecialchars($user['full_name']) . "</strong>!");

                // Handle custom redirect
                $redirect = $_SESSION['redirect_after_login'] ?? null;
                unset($_SESSION['redirect_after_login']);

                if ($user['role'] === 'admin') {
                    header('Location: ' . ($redirect ?? '/poultry/admin/index.php'));
                } else {
                    header('Location: ' . ($redirect ?? '/poultry/shop.php'));
                }
                exit;
            } else {
                $error = 'Invalid email address or password. Please try again.';
            }
        } catch (Exception $e) {
            $error = 'Authentication error: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5 my-md-4">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-5">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-success text-white text-center py-4">
                    <div class="brand-icon-box mx-auto mb-2 bg-white text-success">
                        <i class="bi bi-person-lock fs-3"></i>
                    </div>
                    <h4 class="fw-bold mb-1">Welcome Back</h4>
                    <p class="mb-0 small text-white-50">Log into your FeatherFarm account</p>
                </div>

                <div class="card-body p-4 p-md-5">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                            <i class="bi bi-exclamation-triangle-fill fs-5 me-2"></i>
                            <div><?= $error ?></div>
                        </div>
                    <?php endif; ?>

                    <!-- Demo autofill helper buttons -->
                    <div class="card bg-light border-0 mb-4 p-3 rounded-3">
                        <span class="small fw-bold text-secondary mb-2 d-block">
                            <i class="bi bi-lightning-charge-fill text-warning me-1"></i> Quick Demo Fill:
                        </span>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-sm btn-outline-danger w-50 py-1" onclick="fillCredentials('admin@poultryfarm.com', 'admin123')">
                                <i class="bi bi-shield-check me-1"></i> Admin Demo
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success w-50 py-1" onclick="fillCredentials('customer@poultryfarm.com', 'customer123')">
                                <i class="bi bi-person-check me-1"></i> Customer Demo
                            </button>
                        </div>
                    </div>

                    <form method="POST" action="login.php" class="needs-validation">
                        <div class="mb-3">
                            <label for="email" class="form-label fw-semibold">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email) ?>" placeholder="name@example.com" required autofocus>
                            </div>
                        </div>

                        <div class="mb-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <label for="password" class="form-label fw-semibold mb-0">Password</label>
                            </div>
                            <div class="input-group mt-2">
                                <span class="input-group-text bg-light"><i class="bi bi-key"></i></span>
                                <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
                                <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility()">
                                    <i class="bi bi-eye" id="togglePasswordIcon"></i>
                                </button>
                            </div>
                        </div>

                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-farm-primary py-2 fs-6">
                                <i class="bi bi-box-arrow-in-right me-2"></i> Sign In to Account
                            </button>
                        </div>

                        <div class="text-center text-muted small">
                            Don't have an account yet? 
                            <a href="register.php" class="text-success fw-bold text-decoration-none">Create Account</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function fillCredentials(email, password) {
    document.getElementById('email').value = email;
    document.getElementById('password').value = password;
}

function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const icon = document.getElementById('togglePasswordIcon');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
